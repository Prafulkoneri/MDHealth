import 'package:flutter/material.dart';

Widget circle() {
  return Container(
    height: 150,
    width: 150,
    decoration: const BoxDecoration(
      shape: BoxShape.circle,
      color: Color(0xff4CDB06),
    ),
  );
}