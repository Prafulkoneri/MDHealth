import 'package:flutter/material.dart';

const kDefaultActiveColor = Color(0xff4CDB06);
const black = Colors.black;
