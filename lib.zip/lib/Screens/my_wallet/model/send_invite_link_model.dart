class SendInviteLinkRepons {
  int? status;
  String? message;

  SendInviteLinkRepons({
    required this.status,
    required this.message,
  });
  SendInviteLinkRepons.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
  }
}
/////////////////////////////////

class SendInviteLinkRequestModel {
  String? requestMail;
  String? invitationLink;

  SendInviteLinkRequestModel({
    this.requestMail,
    this.invitationLink,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data["requested_email"] = requestMail;
    data["invitation_link"] = invitationLink;
    return data;
  }
}
