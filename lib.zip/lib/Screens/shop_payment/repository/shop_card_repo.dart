import 'package:http/http.dart' as http;
import 'package:md_health/network/end_point.dart';

class PAymentDoneShopRepo {
  Future<http.Response> paymentDoneShop(token) async {
    print(Uri.parse(Endpoint.shopPaymentDone));

    try {
      return await http.post(Uri.parse(Endpoint.shopPaymentDone), headers: {
        "Authorization": "Bearer $token",
      });
    } catch (e) {
      throw Exception(e);
    }
  }
}
