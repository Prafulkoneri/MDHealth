class ShopCardPaymentResponseModel {
  int? status;
  String? message;
  String? orderIdsho;

  ShopCardPaymentResponseModel({
    required this.status,
    required this.message,
    required this.orderIdsho,
  });
  ShopCardPaymentResponseModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
    orderIdsho = json["order_id"];
  }
}
