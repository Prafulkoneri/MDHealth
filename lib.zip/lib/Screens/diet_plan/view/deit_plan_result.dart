import 'dart:developer';
import 'package:flutter/gestures.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:md_health/Screens/diet_plan/controller/dient_view_controller.dart';
import 'package:md_health/Screens/diet_plan/view/diet_plan_view.dart';
import 'package:md_health/Screens/home/view/custom_select_box.dart';
import 'package:md_health/Screens/diet_plan/view/popup_widget_step_2.dart';
import 'package:md_health/constants/styles/colors.dart';
import 'package:md_health/constants/styles/textstyle.dart';
import 'package:md_health/test_widget.dart';
import 'package:md_health/widget/base_screen.dart';
import 'package:md_health/widget/buttons.dart';
import 'package:md_health/widget/custom_appbar.dart';
import 'package:provider/provider.dart';

class DietPlanResult extends StatefulWidget {
  final String? food;
  final String? calories;
  final String? subscriptionType;
  final String? foodPackageId;
  const DietPlanResult(
      {super.key,
      required this.food,
      required this.calories,
      required this.subscriptionType,
      this.foodPackageId});

  @override
  State<DietPlanResult> createState() => _DietPlanResultState();
}

class _DietPlanResultState extends State<DietPlanResult>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;
  List<String> list = ['Last Added', 'Price', 'Reviews'];
  bool isExpanded = false;
  @override
  void initState() {
    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
      context.read<DietPlanviewController>().initState(context, widget.food,
          widget.subscriptionType, widget.calories, widget.foodPackageId);
    });
    // super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration:
          const Duration(milliseconds: 500), // Adjust the duration as needed
    );
    _animation = Tween<double>(begin: 1, end: 0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.linear),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _showDialog1() {
    debugPrint('helooooooooooooooooooo');
    _animationController.reset();
    _animationController.forward();
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AnimatedBuilder(
              animation: _animation,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(
                      0, MediaQuery.of(context).size.height * _animation.value),
                  child: CustomSelectBox(
                    list: list,
                    title: SelectBoxText(
                      text: 'Sort by',
                      fontWeight: FontWeight.w700,
                    ),
                    tapFun: () {
                      debugPrint('/////////////////////////helooo//////');
                    },
                    button: true,
                    submitActionFnction: () {
                      Navigator.pop(context);
                      // _animationController.reverse();
                    },
                  ),
                );
              });
        });
  }

  void showStepOneDialog({String? id}) {
    debugPrint('/////////////$id///////////////');
    _animationController.reset();
    _animationController.forward();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(
                  0, MediaQuery.of(context).size.height * _animation.value),
              child: PopupDialogWidgetStepTwo(
                  foodPackageId: id.toString(),
                  onTap: () {
                    // Navigator.pop(context);
                    // showDialog(
                    //     context: context,
                    //     builder: (BuildContext context) {
                    //       return PopupDialogWidgetStepOne(
                    //         onTapText: 'Myself',
                    //         child: Padding(
                    //           padding: EdgeInsets.symmetric(horizontal: 10.w),
                    //           child: Text(
                    //             "Who is this purchase for?",
                    //             style: TextStyle(
                    //               fontFamily: 'Campton',
                    //               color: Colors.black,
                    //               fontSize: 17.sp,
                    //               fontWeight: FontWeight.w600,
                    //             ),
                    //           ),
                    //         ),
                    //         onTap: () {
                    //           Navigator.pop(context);
                    //           showDialog(
                    //               context: context,
                    //               builder: (BuildContext context) {
                    //                 return PaymentDetailsViewDiet();
                    //               });
                    //         },
                    //         onTapButton2: () {
                    //           Navigator.push(
                    //             context,
                    //             MaterialPageRoute(
                    //                 builder: (context) =>
                    //                     const InformationFormView()),
                    //           );
                    //         },
                    //       );
                    //     });
                  }),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final read = context.read<DietPlanviewController>();
    final watch = context.watch<DietPlanviewController>();
    return BaseScreen(
      onWillPop: () async {
        Navigator.push(
          context,
          SlidePageRoute(
            page: DietPlanView(
                // packageId:
                //     widget.packageId,
                ),
            direction: SlideDirection.left, // Specify the slide direction here
            delay: Duration(milliseconds: 5000),
          ),
        );

        return false;
      },
      backgroundColor: Colors.white,
      hasScrollView: false,
      appBar: CustomAppBar(
        hasMdTitle: false,
        hasBackButton: true,
        onBackPressed: () {
          Navigator.push(
            context,
            SlidePageRoute(
              page: DietPlanView(
                  // packageId:
                  //     widget.packageId,
                  ),
              direction:
                  SlideDirection.left, // Specify the slide direction here
              delay: Duration(milliseconds: 5000),
            ),
          );
        },
      ),
      content: Builder(builder: (context) {
        return SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                  padding: EdgeInsets.only(top: 35.w, bottom: 59.w),
                  // height: 100.h,
                  width: ScreenUtil().screenWidth,
                  color: Colors.black,
                  child: const Column(
                    // sort
                    children: [
                      Text(
                        "SEARCH",
                        style: TextStyle(
                            fontFamily: 'Campton',
                            color: kDefaultActiveColor,
                            fontSize: 39,
                            fontWeight: FontWeight.w700),
                      ),
                      Text(
                        "RESULTS",
                        style: TextStyle(
                            fontFamily: 'Campton',
                            color: Colors.white,
                            fontSize: 70,
                            fontWeight: FontWeight.w700),
                      )
                    ],
                  )),
              GestureDetector(
                onTap: () {
                  _showDialog1();
                },
                child: Padding(
                  padding: EdgeInsets.only(left: 27.w, top: 18.w),
                  child: Row(
                    children: [
                      SvgPicture.asset(
                        'assets/icons/sort.svg',
                        // alignment: Alignment.topRight,
                      ),
                      SizedBox(
                        width: 5.w,
                      ),
                      // const Text(
                      //   "sort by",
                      // style: TextStyle(
                      //     fontFamily: 'Campton',
                      //     color: Color(0xff818181),
                      //     fontSize: 14,
                      //     fontWeight: FontWeight.w400),
                      // )
                      RichText(
                        // textAlign: TextAlign.start,
                        text: TextSpan(
                          text: 'Sort By',
                          style: TextStyle(
                              fontFamily: 'Campton',
                              color: Color(0xff818181),
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w400),

                          /*defining default style is optional */
                          children: <TextSpan>[
                            TextSpan(
                              text: ' Last Added',
                              style: TextStyle(
                                  fontFamily: 'Gotham',
                                  // decoration: TextDecoration.underline,
                                  color: Color(0xff818181),
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w400),
                              recognizer: new TapGestureRecognizer()
                                ..onTap = () {
                                  // Navigator.push(
                                  //   context,
                                  //   MaterialPageRoute(
                                  //       builder: (context) => SignUpView()),
                                  // );
                                },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                  margin: EdgeInsets.only(
                      left: 18.w, right: 18.w, top: 20.w, bottom: 17.w),
                  child: watch.foodPackagesSearch?.isNotEmpty == true
                      ? ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: watch.foodPackagesSearch?.length ?? 0,
                          itemBuilder: (context, index) {
                            final element = watch.foodPackagesSearch?[index];
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.only(top: 10, bottom: 10),
                                  decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(15)),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.1),
                                          spreadRadius: 1,
                                          blurStyle: BlurStyle.outer,
                                          blurRadius: 10,
                                        )
                                      ]),
                                  padding: EdgeInsets.only(
                                      left: 10.w,
                                      right: 8.w,
                                      top: 16.w,
                                      bottom: 20.w),
                                  child: Stack(
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                " ${element?.packageName}",
                                                // "Hearth Valve Replacement Surgery",
                                                style: TextStyle(
                                                    fontFamily: 'Campton',
                                                    color: Color(0xff212121),
                                                    fontSize: 16.sp,
                                                    fontWeight:
                                                        FontWeight.w700),
                                              ),
                                              element?.verified == "yes"
                                                  ? Image(
                                                      image: AssetImage(
                                                        "assets/images/new_group.png",
                                                      ),
                                                      width: 75.w,
                                                      // height: 60.h,
                                                    )
                                                  : Container()
                                            ],
                                          ),
                                          SizedBox(
                                            height: 7.h,
                                          ),
                                          /////////////
                                          Column(
                                            children: [
                                              Row(
                                                children: [
                                                  SvgPicture.asset(
                                                    'assets/icons/location.svg',
                                                    // alignment: Alignment.topRight,
                                                  ),
                                                  Text(
                                                    "${element?.cityName}",
                                                    // "Beşiktaş / İstanbul",
                                                    style: TextStyle(
                                                        fontStyle:
                                                            FontStyle.italic,
                                                        fontFamily: 'Campton',
                                                        color:
                                                            Color(0xff212121),
                                                        fontSize: 13.sp,
                                                        fontWeight:
                                                            FontWeight.w400),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(
                                                height: 7.h,
                                              ),
                                              Row(
                                                children: [
                                                  SvgPicture.asset(
                                                    'assets/icons/time.svg',
                                                    alignment:
                                                        Alignment.topRight,
                                                  ),
                                                  Text(
                                                    "${element?.subscriptionType}",
                                                    // "Treatment Periods 3-5 days",
                                                    style: TextStyle(
                                                        fontFamily: 'Campton',
                                                        color:
                                                            Color(0xff212121),
                                                        fontSize: 13.sp,
                                                        fontStyle:
                                                            FontStyle.italic,
                                                        fontWeight:
                                                            FontWeight.w400),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10.w,
                                          ),
                                          Text(
                                            "Package Included",
                                            style: TextStyle(
                                              fontFamily: 'Campton',
                                              color: const Color(0xff4CDB06),
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5.w,
                                          ),
                                          Container(
                                            // color:Colors.amber,
                                            child: Container(
                                              child: ListView.builder(
                                                // padding: EdgeInsets.only(
                                                //     bottom: 10.w),
                                                physics:
                                                    const NeverScrollableScrollPhysics(),
                                                shrinkWrap: true,
                                                itemCount: element
                                                        ?.mealTypes?.length ??
                                                    0,
                                                itemBuilder: (context, index) {
                                                  final mealType = element
                                                      ?.mealTypes?[index];
                                                  return Container(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            bottom: 10),
                                                    child: Row(
                                                      children: [
                                                        Image.asset(
                                                          "assets/icons/katman_1.png",
                                                          width: 10.w,
                                                          height: 7.h,
                                                        ),
                                                        SizedBox(
                                                          width: 5.w,
                                                        ),
                                                        Text(
                                                          "${mealType}",
                                                          // "Tour",
                                                          style: TextStyle(
                                                            fontFamily:
                                                                'Campton',
                                                            color: Colors.black,
                                                            fontSize: 13.sp,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                          ),
                                                        ),
                                                        // SvgPicture.asset(
                                                        //   'assets/icons/katman_1.png',
                                                        //   // alignment: Alignment.topRight,
                                                        // ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          ),
                                          Text(
                                            'Meal Service Price ',
                                            style: TextStyle(
                                              fontFamily: 'Campton',
                                              color: kDefaultActiveColor,
                                              fontSize: 17.sp,
                                              letterSpacing: -1,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              if ((element?.monthlySalesPrice ??
                                                          0)
                                                      .toDouble() <
                                                  (element?.monthlyPackagePrice ??
                                                          0)
                                                      .toDouble())
                                                Stack(
                                                  children: [
                                                    // Your other content here

                                                    // Conditionally display slanted line or container

                                                    Positioned.fill(
                                                      child: CustomPaint(
                                                        painter:
                                                            SlantedLinePainter(
                                                                color:
                                                                    Colors.red),
                                                      ),
                                                    ),
                                                    //  / You can customize this container if needed

                                                    Text(
                                                      "${element?.monthlyPackagePrice}",
                                                      style:
                                                          GoogleFonts.notoSans(
                                                        textStyle: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 14,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                )
                                              else
                                                Container(),
                                              element?.discountPrice != ""
                                                  ? Text(
                                                      "  ( ${element?.discountPrice}% )",
                                                      style:
                                                          GoogleFonts.notoSans(
                                                        textStyle: TextStyle(
                                                          color:
                                                              kDefaultActiveColor,
                                                          fontSize: 14,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                                      ),
                                                    )
                                                  : Container()
                                            ],
                                          ),

                                          RichText(
                                            text: TextSpan(
                                              style: TextStyle(
                                                fontFamily: 'Campton',
                                                color: Colors.black,
                                                fontSize: 16.sp,
                                                letterSpacing: -1.5,
                                                fontWeight: FontWeight.w600,
                                              ),
                                              children: [
                                                TextSpan(
                                                    text:
                                                        // '${element?.foodPackageId} ₺',
                                                        '${element?.monthlySalesPrice} ₺',
                                                    style: TextStyle(
                                                        fontSize: 20.sp)),
                                                TextSpan(
                                                    text:
                                                        ' (${element?.salesPrice} ₺ per meal) ')
                                              ],
                                            ),
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(top: 25.w),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                PrimaryButton(
                                                  height: 35.h,
                                                  width: 160.w,
                                                  color: kDefaultActiveColor,
                                                  onTap: () {
                                                    showStepOneDialog(
                                                        id: element
                                                            ?.foodPackageId
                                                            .toString());
                                                  },
                                                  text: 'Purchase Meal Service',
                                                  textStyle: TextStyle(
                                                    fontFamily: 'Campton',
                                                    color: Colors.black,
                                                    fontSize: 16.sp,
                                                    letterSpacing: -1,
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                  textColor: Colors.black,
                                                ),
                                                SizedBox(
                                                  width: 15.w,
                                                ),
                                                GestureDetector(
                                                  onTap: () {
                                                    print(
                                                        element?.foodPackageId);
                                                    // return;
                                                    read.addToFavMenuFood(
                                                      context,
                                                      element?.foodPackageId
                                                          .toString(),
                                                      "food",
                                                    );
                                                  },
                                                  child: element?.isFavorite !=
                                                          "yes"
                                                      ? Container(
                                                          height: 35.h,
                                                          width: 46.w,
                                                          padding:
                                                              EdgeInsets.only(
                                                                  left: 3.5.w,
                                                                  top: 7.w,
                                                                  bottom: 7.w),
                                                          alignment:
                                                              Alignment.center,
                                                          decoration: BoxDecoration(
                                                              color: Color(
                                                                  0xffF55C5C),
                                                              borderRadius: BorderRadius
                                                                  .all(Radius
                                                                      .circular(
                                                                          5))),
                                                          child:
                                                              SvgPicture.asset(
                                                            'assets/icons/favorite.svg',
                                                          ),
                                                        )
                                                      : Container(
                                                          height: 35.h,
                                                          width: 46.w,
                                                          padding:
                                                              EdgeInsets.only(
                                                                  left: 3.5.w,
                                                                  top: 7.w,
                                                                  bottom: 7.w),
                                                          alignment:
                                                              Alignment.center,
                                                          decoration: BoxDecoration(
                                                              color:
                                                                  Colors.grey,
                                                              borderRadius: BorderRadius
                                                                  .all(Radius
                                                                      .circular(
                                                                          5))),
                                                          child:
                                                              SvgPicture.asset(
                                                            'assets/icons/favorite.svg',
                                                          ),
                                                        ),
                                                ),

                                                // GestureDetector(
                                                //   onTap: () {
                                                //     print(element?.foodPackageId);
                                                //     // return;
                                                //     read.addToFavMenuFood(
                                                //       context,
                                                //       element?.foodPackageId
                                                //           .toString(),
                                                //       "food",
                                                //     );
                                                // showDialog(
                                                //     context: context,
                                                //     builder: (BuildContext
                                                //         context) {
                                                //       return AlertDialog(
                                                //         shape:
                                                //             const RoundedRectangleBorder(
                                                //           borderRadius:
                                                //               BorderRadius.all(
                                                //                   Radius.circular(
                                                //                       20.0)),
                                                //         ),
                                                //         backgroundColor:
                                                //             const Color(
                                                //                 0xffF55C5C),
                                                //         scrollable: true,
                                                //         content: Column(
                                                //           mainAxisAlignment:
                                                //               MainAxisAlignment
                                                //                   .center,
                                                //           crossAxisAlignment:
                                                //               CrossAxisAlignment
                                                //                   .end,
                                                //           children: <Widget>[
                                                //             GestureDetector(
                                                //               onTap: () {
                                                //                 Navigator.pop(
                                                //                     context);
                                                //               },
                                                //               child:
                                                //                   SvgPicture
                                                //                       .asset(
                                                //                 'assets/icons/CloseSquare.svg',
                                                //                 // width: 30,
                                                //                 // alignment: Alignment.topRight,
                                                //               ),
                                                //             ),
                                                //             Center(
                                                //               child: Column(
                                                //                 children: [
                                                //                   SvgPicture
                                                //                       .asset(
                                                //                     'assets/icons/favorite.svg',
                                                //                     width:
                                                //                         54.w,
                                                //                     height:
                                                //                         37.h,
                                                //                     // alignment: Alignment.topRight,
                                                //                   ),
                                                //                   // SizedBox(
                                                //                   //   height:
                                                //                   //       10.h,
                                                //                   // ),
                                                //                   Text(
                                                //                     "Added to favorites!",
                                                //                     style:
                                                //                         TextStyle(
                                                //                       fontFamily:
                                                //                           'Campton',
                                                //                       color: Colors
                                                //                           .white,
                                                //                       fontSize:
                                                //                           17.sp,
                                                //                       fontWeight:
                                                //                           FontWeight.w600,
                                                //                     ),
                                                //                   ),
                                                //                 ],
                                                //               ),
                                                //             ),
                                                //           ],
                                                //         ),
                                                //       );
                                                //     });
                                                //   },
                                                //   child: watch.isFavProduct
                                                //       ? Container(
                                                //           height: 35.h,
                                                //           width: 46.w,
                                                //           padding:
                                                //               EdgeInsets.only(
                                                //                   left: 3.5.w,
                                                //                   top: 7.w,
                                                //                   bottom: 7.w),
                                                //           alignment:
                                                //               Alignment.center,
                                                //           decoration: BoxDecoration(
                                                //               color: Color(
                                                //                   0xffF55C5C),
                                                //               borderRadius:
                                                //                   BorderRadius
                                                //                       .all(Radius
                                                //                           .circular(
                                                //                               5))),
                                                //           child: SvgPicture.asset(
                                                //             'assets/icons/favorite.svg',
                                                //           ),
                                                //         )
                                                //       : Container(
                                                //           height: 35.h,
                                                //           width: 46.w,
                                                //           padding:
                                                //               EdgeInsets.only(
                                                //                   left: 3.5.w,
                                                //                   top: 7.w,
                                                //                   bottom: 7.w),
                                                //           alignment:
                                                //               Alignment.center,
                                                //           decoration: BoxDecoration(
                                                //               color: Colors.grey,
                                                //               borderRadius:
                                                //                   BorderRadius
                                                //                       .all(Radius
                                                //                           .circular(
                                                //                               5))),
                                                //           child: SvgPicture.asset(
                                                //             'assets/icons/favorite.svg',
                                                //           ),
                                                //         ),
                                                // )
                                              ],
                                            ),
                                          ),
                                          isExpanded
                                              ? Container(
                                                  child: Column(
                                                    children: [
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                top: 60.w,
                                                                bottom: 20.w),
                                                        child: Text(
                                                          'Weekly Menu',
                                                          style: TextStyle(
                                                            fontFamily:
                                                                'Campton',
                                                            color:
                                                                kDefaultActiveColor,
                                                            fontSize: 22.sp,
                                                            letterSpacing: -1,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                bottom: 20.w),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      top: 5.w,
                                                                      bottom:
                                                                          5.w),
                                                              child: Text(
                                                                'Day 1',
                                                                style:
                                                                    TextStyle(
                                                                  fontFamily:
                                                                      'Campton',
                                                                  color:
                                                                      kDefaultActiveColor,
                                                                  fontSize:
                                                                      18.sp,
                                                                  letterSpacing:
                                                                      -1,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                ),
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Breakfast',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 10.w,
                                                                ),
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Lunch',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              height: 10.h,
                                                            ),
                                                            Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  'Dinner',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                bottom: 20.w),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      top: 5.w,
                                                                      bottom:
                                                                          5.w),
                                                              child: Text(
                                                                'Day 2',
                                                                style:
                                                                    TextStyle(
                                                                  fontFamily:
                                                                      'Campton',
                                                                  color:
                                                                      kDefaultActiveColor,
                                                                  fontSize:
                                                                      18.sp,
                                                                  letterSpacing:
                                                                      -1,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                ),
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Breakfast',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 10.w,
                                                                ),
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Lunch',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              height: 10.h,
                                                            ),
                                                            Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  'Dinner',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                bottom: 20.w),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      top: 5.w,
                                                                      bottom:
                                                                          5.w),
                                                              child: Text(
                                                                'Day 3',
                                                                style:
                                                                    TextStyle(
                                                                  fontFamily:
                                                                      'Campton',
                                                                  color:
                                                                      kDefaultActiveColor,
                                                                  fontSize:
                                                                      18.sp,
                                                                  letterSpacing:
                                                                      -1,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                ),
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Breakfast',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 10.w,
                                                                ),
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Lunch',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              height: 10.h,
                                                            ),
                                                            Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  'Dinner',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                bottom: 20.w),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      top: 5.w,
                                                                      bottom:
                                                                          5.w),
                                                              child: Text(
                                                                'Day 4',
                                                                style:
                                                                    TextStyle(
                                                                  fontFamily:
                                                                      'Campton',
                                                                  color:
                                                                      kDefaultActiveColor,
                                                                  fontSize:
                                                                      18.sp,
                                                                  letterSpacing:
                                                                      -1,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                ),
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Breakfast',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 10.w,
                                                                ),
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Lunch',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              height: 10.h,
                                                            ),
                                                            Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  'Dinner',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                bottom: 20.w),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      top: 5.w,
                                                                      bottom:
                                                                          5.w),
                                                              child: Text(
                                                                'Day 5',
                                                                style:
                                                                    TextStyle(
                                                                  fontFamily:
                                                                      'Campton',
                                                                  color:
                                                                      kDefaultActiveColor,
                                                                  fontSize:
                                                                      18.sp,
                                                                  letterSpacing:
                                                                      -1,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                ),
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Breakfast',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 10.w,
                                                                ),
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Lunch',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              height: 10.h,
                                                            ),
                                                            Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  'Dinner',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                bottom: 20.w),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      top: 5.w,
                                                                      bottom:
                                                                          5.w),
                                                              child: Text(
                                                                'Day 6',
                                                                style:
                                                                    TextStyle(
                                                                  fontFamily:
                                                                      'Campton',
                                                                  color:
                                                                      kDefaultActiveColor,
                                                                  fontSize:
                                                                      18.sp,
                                                                  letterSpacing:
                                                                      -1,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                ),
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Breakfast',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 10.w,
                                                                ),
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Lunch',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              height: 10.h,
                                                            ),
                                                            Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  'Dinner',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                bottom: 20.w),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      top: 5.w,
                                                                      bottom:
                                                                          5.w),
                                                              child: Text(
                                                                'Day 7',
                                                                style:
                                                                    TextStyle(
                                                                  fontFamily:
                                                                      'Campton',
                                                                  color:
                                                                      kDefaultActiveColor,
                                                                  fontSize:
                                                                      18.sp,
                                                                  letterSpacing:
                                                                      -1,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                ),
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Breakfast',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 10.w,
                                                                ),
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Lunch',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w600,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                      style:
                                                                          TextStyle(
                                                                        fontFamily:
                                                                            'Campton',
                                                                        color: Colors
                                                                            .black,
                                                                        fontSize:
                                                                            16.sp,
                                                                        letterSpacing:
                                                                            -1,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              height: 10.h,
                                                            ),
                                                            Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  'Dinner',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Boiled Egg\nCheese\nOlive\nHoney & Butter',
                                                                  style:
                                                                      TextStyle(
                                                                    fontFamily:
                                                                        'Campton',
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        16.sp,
                                                                    letterSpacing:
                                                                        -1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                )
                                              : Container(),
                                        ],
                                      ),
                                      Positioned(
                                        top: 60,
                                        right: 15,
                                        child: GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              isExpanded = !isExpanded;
                                            });
                                          },
                                          child: SvgPicture.asset(
                                            'assets/icons/ViewDetails Button (1).svg',
                                            // alignment: Alignment.topRight,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          },
                        )
                      : Center(
                          child: Column(
                            children: [
                              SizedBox(
                                height: 120.h,
                              ),
                              SvgPicture.asset(
                                "assets/icons/kiran_no_data_found.svg",
                                // width: 10,
                              ),
                            ],
                          ),
                        )),
            ],
          ),
        );
      }),
    );
  }
}

class SlantedLinePainter extends CustomPainter {
  final Color color;

  SlantedLinePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = 1.0;

    canvas.drawLine(
      // Top left
      Offset(size.width * 0.95, 2),
      Offset(2, size.height * 0.8), // Bottom right
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
