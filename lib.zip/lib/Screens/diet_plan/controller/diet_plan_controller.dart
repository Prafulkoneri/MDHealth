import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:md_health/Screens/diet_plan/model/calaries_model.dart';
import 'package:md_health/Screens/diet_plan/model/food_model.dart';
import 'package:md_health/Screens/diet_plan/model/most_used_product.dart';
import 'package:md_health/Screens/diet_plan/model/type_model.dart';
import 'package:md_health/Screens/diet_plan/repositiory/calaries_repo.dart';
import 'package:md_health/Screens/diet_plan/repositiory/food_repo.dart';
import 'package:md_health/Screens/diet_plan/repositiory/most_used_repo.dart';
import 'package:md_health/Screens/diet_plan/repositiory/type_repo.dart';
import 'package:md_health/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DietPlanController extends ChangeNotifier {
  bool isLoading = true;
  String selectedText = '';
  String selectedTexttype = '';
  String selectedTextcalaries = '';
  int selectedTextIndex = -1; // Assuming -1 represents no selection
  int selectedTextIndextype = -1; // Assuming -1 represents no selection
  int selectedTextIndexcalories = -1; // Assuming -1 represents no selection

  GetFoodRepo getFoodRepo = GetFoodRepo();
  MostUsedFoodRepo mostUsedFoodRepo = MostUsedFoodRepo();
  TypeSubscriptionRepo typeSubscriptionRepo = TypeSubscriptionRepo();
  CaloriesRepo caloriesRepo = CaloriesRepo();
  List<FoodList>? foodData;
  List<CaloriesData>? caloriesData;
  List<SubscriptionData>? subscriptiondata;

  Future<void> initState(context) async {
    await getFood(context);
    await getCalories(context);
    await getSubScriptionType(context);
    await mostUsedFood(context);
    selectedTextIndex = -1;
    selectedTextIndextype = -1;
    selectedTextIndexcalories = -1;
    notifyListeners();
  }

  void setSelectedText(value, index) {
    selectedText = value;
    selectedTextIndex = index;
    notifyListeners();
  }
  ///////////setSelectedTextCalories

  void setSelectedTexttypes(value, index) {
    selectedTexttype = value;
    selectedTextIndextype = index;
    notifyListeners();
  }

  ////////////
  void setSelectedTextCalories(value, index) {
    selectedTextcalaries = value;
    selectedTextIndexcalories = index;
    notifyListeners();
  }

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  Future<void> getFood(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    getFoodRepo.getfood(pref.getString("successToken")).then((response) {
      log(response.body);
      final result = FoodResponseModel.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          foodData = result.foodData;

          showLoader(false);
          Utils.showPrimarySnackbar(context, "", type: SnackType.success);
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, "", type: SnackType.error);
        }
      } else {
        Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  //////////////////////////////////////////////////////////////////////////////
  List<MostUsedData>? mostuseddata;

  Future<void> mostUsedFood(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    mostUsedFoodRepo.mostFood(pref.getString("successToken")).then((response) {
      log(response.body);
      final result = MostUsedProviderFoodResponseModel.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          mostuseddata = result.mostuseddata;

          showLoader(false);
          Utils.showPrimarySnackbar(context, "", type: SnackType.success);
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, "", type: SnackType.error);
        }
      } else {
        Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

/////////////////////////////////////////////////////////////////////////////////////
  Future<void> getCalories(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    caloriesRepo.calariesData(pref.getString("successToken")).then((response) {
      log(response.body);
      final result = CaloriesResponseModel.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          caloriesData = result.caloriesData;

          showLoader(false);
          Utils.showPrimarySnackbar(context, "", type: SnackType.success);
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, "", type: SnackType.error);
        }
      } else {
        Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

//////////////////////////////////////////////\
  Future<void> getSubScriptionType(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    typeSubscriptionRepo
        .typesub(pref.getString("successToken"))
        .then((response) {
      log(response.body);
      final result = SubscriptionType.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          subscriptiondata = result.subscriptiondata;
          showLoader(false);
          Utils.showPrimarySnackbar(context, "", type: SnackType.success);
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, "", type: SnackType.error);
        }
      } else {
        Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
}
