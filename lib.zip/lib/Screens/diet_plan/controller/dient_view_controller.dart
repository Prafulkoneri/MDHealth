import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:md_health/Screens/diet_plan/model/add_to_fav_food_repo.dart';
import 'package:md_health/Screens/diet_plan/model/calaries_model.dart';
import 'package:md_health/Screens/diet_plan/model/calculation_model.dart';
import 'package:md_health/Screens/diet_plan/model/diet_view_model.dart';
import 'package:md_health/Screens/diet_plan/model/get_who-purchase_model.dart';
import 'package:md_health/Screens/diet_plan/model/type_model.dart';
import 'package:md_health/Screens/diet_plan/model/view_menu_model.dart';
import 'package:md_health/Screens/diet_plan/repositiory/add_fav_repo.dart';
import 'package:md_health/Screens/diet_plan/repositiory/calculation_repo.dart';
import 'package:md_health/Screens/diet_plan/repositiory/dient_view_repo.dart';
import 'package:md_health/Screens/diet_plan/repositiory/get_who_purches_repo.dart';
import 'package:md_health/Screens/diet_plan/repositiory/type_repo.dart';
import 'package:md_health/Screens/diet_plan/repositiory/view_menu_repo.dart';
import 'package:md_health/utils/utils.dart';
import 'package:md_health/widget/loading_overlay.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DietPlanviewController extends ChangeNotifier {
  bool isLoading = true;
  String food = '';
  String calories = '';
  String newSalePrice = '';
  String? foodpackageId;
  String? salesPrice;
  String? status;
  String? mealType;
  String subscriptionType = '';
  String selectedTextfood = '';
  String selectedTexttype = '';
  String selectedTextcalories = '';
  int selectedTextIndexfood = -1; // Assuming -1 represents no selection
  int selectedTextIndextype = 0; // Assuming -1 represents no selection
  int selectedTextIndexcalories = -1; // Assuming -1 represents no selection

  DietViewRepo dietViewRepo = DietViewRepo();
  GetwhoPurchaseRepo getwhoPurchaseRepo = GetwhoPurchaseRepo();
  CalculationRepo calculationRepo = CalculationRepo();
  MENUDietViewRepo menuietViewRepo = MENUDietViewRepo();
  addToFavFood addtoFavFood = addToFavFood();
  List<bool> selectAddonServicesList = [true];
  getWhoPurchaseData? whoPurhasedata;
  List<MealTypeWho>? mealTypeswho;
  List<CaloriesData>? caloriesData;

  // List<FoodList>? foodData;

  Future<void> initState(context, fName, subscType, cal, fpId) async {
    await foodViewDetails(context, fName, subscType, cal);
    gwtWhoTopUrchase(context, fpId);
    // viewMenuDetails(
    //   context,
    //   pId,
    // );
    notifyListeners();
  }

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  List<bool> selectedAddOnServicesStatus = [];
  List selectedAddOnServicesId = [];
  void onAddOnServicesSelected(BuildContext context, int index, String id) {
    LoadingOverlay.of(context).show();

    // Toggle the selection status of the add-on service at the given index
    selectAddonServicesList[index] = !selectAddonServicesList[index];

    if (selectAddonServicesList[index]) {
      // If the checkbox is checked, add the service ID to the list
      selectedAddOnServicesId.add(id);
      selectedAddOnServicesStatus.add(true); // Add true for checked status
    } else {
      // If the checkbox is unchecked, remove the service ID from the list
      selectedAddOnServicesId.remove(id);
      if (index < selectedAddOnServicesStatus.length) {
        // Ensure index is within valid range
        selectedAddOnServicesStatus.removeAt(index); // Remove status at index
      }
    }

    // Recalculate the price based on the selected add-on services and other parameters
    calculationprice(
      context: context,
      saPrices: '',
      cheStatus: selectedAddOnServicesStatus.isNotEmpty
          ? selectedAddOnServicesStatus.join(',')
          : '',
      fpId: whoPurhasedata?.foodPackageId.toString(),
      mType: selectedAddOnServicesId.isNotEmpty
          ? selectedAddOnServicesId.join(',')
          : '',
      stype: '',
    );

    print("Selected Add-On Services IDs: $selectedAddOnServicesId");

    LoadingOverlay.of(context).hide();
    notifyListeners();
  }

  // List<bool> selectedAddOnServicesStatus = [];

  // List selectedAddOnServicesId = [];
  // // void onAddOnServicesSelected(BuildContext context, int index, String id) {
  // //   LoadingOverlay.of(context).show();
  // //   selectAddonServicesList[index] = !selectAddonServicesList[index];

  // //   if (selectAddonServicesList[index]) {
  // //     selectedAddOnServicesId.removeWhere((item) => item == id);
  // //     selectedAddOnServicesId.insert(0, id);
  // //     selectedAddOnServicesStatus[index] =
  // //         true; // Update status at index to true
  // //   } else {
  // //     selectedAddOnServicesId.removeWhere((item) => item == id);
  // //     selectedAddOnServicesStatus[index] =
  // //         false; // Update status at index to false
  // //   }

  // //   calculationprice(
  // //     context: context,
  // //     saPrices: '',
  // //     cheStatus: selectedAddOnServicesStatus.isNotEmpty
  // //         ? selectedAddOnServicesStatus.join(',')
  // //         : '',
  // //     fpId: whoPurhasedata?.foodPackageId.toString(),
  // //     mType: selectedAddOnServicesId.isNotEmpty
  // //         ? selectedAddOnServicesId.join(',')
  // //         : '',
  // //     stype: '',
  // //   );

  // //   print(selectedAddOnServicesId);
  // //   LoadingOverlay.of(context).hide();
  // //   notifyListeners();
  // // }

  // void onAddOnServicesSelected(BuildContext context, int index, String id) {
  //   LoadingOverlay.of(context).show();
  //   selectAddonServicesList[index] = !selectAddonServicesList[index];
  //   if (selectAddonServicesList[index]) {
  //     selectedAddOnServicesId.removeWhere((item) => item == id);
  //     selectedAddOnServicesId.insert(0, id);
  //     if (selectedAddOnServicesStatus.isNotEmpty) {
  //       selectedAddOnServicesStatus.add(true); // Add true for checked status
  //     } else {
  //       selectedAddOnServicesStatus = [true]; // Initialize list if empty
  //     }
  //   } else {
  //     selectedAddOnServicesId.removeWhere((item) => item == id);
  //     if (selectedAddOnServicesStatus.isNotEmpty &&
  //         index < selectedAddOnServicesStatus.length) {
  //       selectedAddOnServicesStatus.removeAt(index); // Remove status at index
  //     } else {
  //       selectedAddOnServicesStatus.insert(
  //           index, false); // Insert false for unchecked status
  //     }
  //   }
  //   calculationprice(
  //     context: context,
  //     saPrices: '',
  //     cheStatus: selectedAddOnServicesStatus.isNotEmpty
  //         ? selectedAddOnServicesStatus.join(',')
  //         : '',
  //     fpId: whoPurhasedata?.foodPackageId.toString(),
  //     mType: selectedAddOnServicesId.isNotEmpty
  //         ? selectedAddOnServicesId.join(',')
  //         : '',
  //     stype: '',
  //   );
  //   print("object");
  //   print(selectedAddOnServicesId);
  //   print("object");
  //   LoadingOverlay.of(context).hide();
  //   notifyListeners();
  // }

  // void onAddOnServicesSelected(BuildContext context, int index, String id) {
  //   LoadingOverlay.of(context).show();
  //   selectAddonServicesList[index] = !selectAddonServicesList[index];
  //   if (selectAddonServicesList[index]) {
  //     selectedAddOnServicesId.removeWhere((item) => item == id);
  //     selectedAddOnServicesId.insert(0, id);
  //     if (selectedAddOnServicesStatus.isNotEmpty) {
  //       selectedAddOnServicesStatus.add(true); // Add true for checked status
  //     } else {
  //       selectedAddOnServicesStatus = [true]; // Initialize list if empty
  //     }
  //   } else {
  //     selectedAddOnServicesId.removeWhere((item) => item == id);
  //     if (selectedAddOnServicesStatus.isNotEmpty &&
  //         index < selectedAddOnServicesStatus.length) {
  //       selectedAddOnServicesStatus.removeAt(index); // Remove status at index
  //     }
  //   }
  //   calculationprice(
  //     context: context,
  //     saPrices: '',
  //     cheStatus: selectedAddOnServicesStatus.isNotEmpty
  //         ? selectedAddOnServicesStatus.join(',')
  //         : '',
  //     fpId: whoPurhasedata?.foodPackageId.toString(),
  //     mType: selectedAddOnServicesId.isNotEmpty
  //         ? selectedAddOnServicesId.join(',')
  //         : '',
  //     stype: '',
  //   );
  //   print(selectedAddOnServicesId);
  //   LoadingOverlay.of(context).hide();
  //   notifyListeners();
  // }

  // void onAddOnServicesSelected(BuildContext context, int index, String id) {
  //   // LoadingOverlay.of(context).show();
  //   selectAddonServicesList[index] = !selectAddonServicesList[index];
  //   if (selectAddonServicesList[index]) {
  //     selectedAddOnServicesId.removeWhere((item) => item == id);
  //     selectedAddOnServicesId.insert(0, id);
  //     selectedAddOnServicesStatus.add(true); // Add true for checked status
  //   } else {
  //     selectedAddOnServicesId.removeWhere((item) => item == id);
  //     selectedAddOnServicesStatus.removeAt(index); // Remove status at index
  //   }
  //   calculationprice(
  //     context: context,
  //     saPrices: '',
  //     cheStatus: selectedAddOnServicesStatus
  //         .join(','), // Convert status list to comma-separated string
  //     fpId: whoPurhasedata?.foodPackageId.toString(),
  //     mType: selectedAddOnServicesId
  //         .join(','), // Convert list to comma-separated string
  //     stype: '',
  //   );
  //   print(selectedAddOnServicesId);
  //   // LoadingOverlay.of(context).hide();
  //   notifyListeners();
  // }
  // List<bool> selectedAddOnServicesStatus = [];
  // List selectedAddOnServicesId = [];

//   List<bool> selectedAddOnServicesStatus = [];
// List<String> selectedAddOnServicesId = [];
//   List<bool> selectedAddOnServicesStatus = [];
//   List<String> selectedAddOnServicesId = [];

// //   List<bool> selectedAddOnServicesStatus =

//   void onAddOnServicesSelected(BuildContext context, int index, String id) {
//     if (index < 0 || index >= selectedAddOnServicesStatus.length) {
//       // Invalid index, handle the error here
//       print('Invalid index: $index');
//       return;
//     }

//     // Toggle the status at the specified index
//     selectedAddOnServicesStatus[index] = !selectedAddOnServicesStatus[index];

//     if (selectedAddOnServicesStatus[index]) {
//       // If the service is selected, add its ID to the list
//       selectedAddOnServicesId.add(id);
//     } else {
//       // If the service is deselected, remove its ID from the list
//       selectedAddOnServicesId.remove(id);
//     }

//     calculationprice(
//       context: context,
//       saPrices: '',
//       cheStatus: selectedAddOnServicesStatus
//           .map((status) => status ? 'true' : 'false')
//           .join(','),
//       fpId: whoPurhasedata?.foodPackageId.toString(),
//       mType: selectedAddOnServicesId.join(','),
//       stype: '',
//     );

//     print(selectedAddOnServicesId);
//     notifyListeners();
//   }

  /////////////////////////////////////////////////////////////
  CalculationData? calculationdata;

  CalculationRequestModel get calculationRequestModel =>
      CalculationRequestModel(
        foodpackageId: foodpackageId.toString(),
        subscriptionType: selectedTexttype.toString(),
        salePrice: salesPrice.toString(),
        mealType: mealType,
        status: status,
      );
  Future<void> calculationprice(
      {required BuildContext context,
      required saPrices,
      required mType,
      required fpId,
      required stype,
      required cheStatus}) async {
    salesPrice = saPrices;
    mealType = mType;
    foodpackageId = fpId;
    subscriptionType = stype;
    status = cheStatus;
    log(salesPrice = saPrices);
    log(mealType = mType);
    log(foodpackageId = fpId);
    log(status = cheStatus);
    showLoader(true);

    SharedPreferences pref = await SharedPreferences.getInstance();
    calculationRepo
        .calcluationprice(
            calculationRequestModel, pref.getString("successToken"))
        .then((response) async {
      log(response.body);
      debugPrint('/////////////');
      final result =
          CalculationMealResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        newSalePrice = result.calculationdata?.salePrices.toString() ?? '';
        debugPrint('/////////////');
        log(newSalePrice.toString());
        debugPrint('/////////////');
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  void setSelectedTextfood(value, index) {
    selectedTextfood = value;
    selectedTextIndexfood = index;
    notifyListeners();
  }

  void setSelectedTexttype1(context, value, index) {
    selectedTexttype = value;
    selectedTextIndextype = index;
    calculationprice(
      context: context,
      saPrices: '',
      cheStatus: '',
      fpId: whoPurhasedata?.foodPackageId.toString(),
      mType: '',
      stype: '',
    );
    notifyListeners();
  }

  void setSelectedTextCalories(value, index) {
    selectedTextcalories = value;
    selectedTextIndexcalories = index;
    notifyListeners();
  }

  DietViewListData? dietviewdata;
  List<FoodPackagesSearch>? foodPackagesSearch;
  List<String>? mealTypes;

  DietViewRequestModel get dietViewRequestModel => DietViewRequestModel(
        foodType: food,
        subscriptionType: subscriptionType,
        calories: calories,
      );
  Future<void> foodViewDetails(context, fName, subscType, cal) async {
    food = fName.toString();
    subscriptionType = subscType.toString();
    calories = cal.toString();
    showLoader(true);

    SharedPreferences pref = await SharedPreferences.getInstance();
    dietViewRepo
        .dietView(dietViewRequestModel, pref.getString("successToken"))
        .then((response) async {
      debugPrint('/////////////');
      final result = DietViewReponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        dietviewdata = result.dietviewdata;
        isFavProduct =
            dietviewdata?.foodPackagesSearch?.first.isFavorite == "yes"
                ? true
                : false;

        foodPackagesSearch = result.dietviewdata?.foodPackagesSearch;
        print("juhujkiuyol,oi;l");
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  ///////////////////////////////////////////////////

  ///////////////////////////////////

  GetWhoPurchaseRequestModel get getWhoPurchaseRequestModel =>
      GetWhoPurchaseRequestModel(foodpackageId: foodpackageId);
  Future<void> gwtWhoTopUrchase(context, fpId) async {
    foodpackageId = fpId;

    showLoader(true);

    SharedPreferences pref = await SharedPreferences.getInstance();
    getwhoPurchaseRepo
        .whopurchase(getWhoPurchaseRequestModel, pref.getString("successToken"))
        .then((response) async {
      log(response.body);
      debugPrint('///////praful//////');
      final result =
          GetWhoPurchaseReponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        whoPurhasedata = result.whoPurhasedata;

        print("object11111111111111111111111111111");
        log(result.whoPurhasedata?.salesPrice ?? '');
        print("object2222222222222222222222222222222222");
        newSalePrice = result.whoPurhasedata?.salesPrice ?? '';
        mealTypeswho = result.mealTypeswho;
        selectAddonServicesList = List.generate(
          mealTypeswho?.length ?? 0,
          (index) => true,
        );
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  TextEditingController BirthDateController = TextEditingController();

  void onToDateSelected(date) {
    BirthDateController.text = date;
    notifyListeners();
  }

  TypeSubscriptionRepo typeSubscriptionRepo = TypeSubscriptionRepo();
  List<SubscriptionData>? subscriptiondata;
  Future<void> getSubScriptionType(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    typeSubscriptionRepo
        .typesub(pref.getString("successToken"))
        .then((response) {
      log(response.body);
      final result = SubscriptionType.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          subscriptiondata = result.subscriptiondata;
          showLoader(false);
          Utils.showPrimarySnackbar(context, "", type: SnackType.success);
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, "", type: SnackType.error);
        }
      } else {
        Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  ViewMenuRequestNModel get viewmenurequestNModel =>
      ViewMenuRequestNModel(foodpackageId: foodpackageId);
  List<ViewMenuList>? viewmenuList;
  String? category;
  List<MealType>? mealTypen;
  String? meal;
  List<String>? mealName;
  Future<void> viewMenuDetails(
    context,
    pId,
  ) async {
    foodpackageId = pId.toString();

    showLoader(true);

    SharedPreferences pref = await SharedPreferences.getInstance();
    menuietViewRepo
        .mENUdietView(
      viewmenurequestNModel,
      pref.getString("successToken"),
    )
        .then((response) async {
      debugPrint('/////////////');
      final result = ViewMenuResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        print("juhujkiuyol,oi;l");
        viewmenuList = result.viewmenuList;
        mealTypen = result.viewmenuList?.first.mealTypen;
        mealName = result.viewmenuList?.first.mealTypen?.first.mealName;
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  //////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////

  // AddFavFooDRequestModel get addFavFooDRequestModel =>
  //     AddFavFooDRequestModel(packageId: packageId);
  bool isFavProduct = true; //fvrt Product
  Future<void> addToFavMenuFood(
    context,
    packId,
    favtype,
  ) async {
    SharedPreferences pref = await SharedPreferences.getInstance();

    addtoFavFood
        .foodAddFav(
            AddFavFooDRequestModel(
              favtype: "food",
              packageId: packId,
            ),
            pref.getString("successToken"))
        .then((response) async {
      log("response.body${response.body}");
      final result =
          AddFavFooDResponseMOdel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        if (result.status == 200) {
          if (result.favStatus == "added") {
            isFavProduct = true;
          } else {
            isFavProduct = false;
          }

          showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20.0)),
                  ),
                  backgroundColor: const Color(0xffF55C5C),
                  scrollable: true,
                  content: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: SvgPicture.asset(
                          'assets/icons/CloseSquare.svg',
                          // width: 30,
                          // alignment: Alignment.topRight,
                        ),
                      ),
                      Center(
                        child: Column(
                          children: [
                            SvgPicture.asset(
                              'assets/icons/favorite.svg',
                              width: 54.w,
                              height: 37.h,
                              // alignment: Alignment.topRight,
                            ),
                            // SizedBox(
                            //   height:
                            //       10.h,
                            // ),
                            Text(
                              "Added to favorites!",
                              style: TextStyle(
                                fontFamily: 'Campton',
                                color: Colors.white,
                                fontSize: 17.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              });
          notifyListeners();
        } else if (result.status == 404) {
          // Handle 404 status code here
          Utils.showPrimarySnackbar(context, result.message,
              type: SnackType.error);
          notifyListeners();
        }
      } else if (result.status == 404) {
        // Handle 404 status code here
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
        notifyListeners();
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
}
