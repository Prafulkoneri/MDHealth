class DietViewRequestModel {
  String? foodType;
  String? calories;
  String? subscriptionType;

  DietViewRequestModel({
    this.foodType,
    this.calories,
    this.subscriptionType,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data["subscription_type"] = subscriptionType;
    data["food_type"] = foodType;
    data["calories"] = calories;
    return data;
  }
}

/////////////////////////////////////////////////////////////////////////////
class DietViewReponseModel {
  int? status;
  String? message;
  DietViewListData? dietviewdata;

  DietViewReponseModel({
    required this.status,
    required this.message,
    required this.dietviewdata,
  });
  DietViewReponseModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
    if (json['data'] != null) {
      if (json['data'] is List) {
        // Handle list data
        dietviewdata = DietViewListData(foodPackagesSearch: []);
        dietviewdata!.foodPackagesSearch = List<FoodPackagesSearch>.from(
          json['data'].map((model) => FoodPackagesSearch.fromJson(model)),
        );
      } else if (json['data'] is Map<String, dynamic>) {
        // Handle map data
        dietviewdata = DietViewListData.fromJson(json['data']);
      }
    }
  }
}

class DietViewListData {
  List<FoodPackagesSearch>? foodPackagesSearch;

  DietViewListData({
    required this.foodPackagesSearch,
  });
  DietViewListData.fromJson(Map<String, dynamic> json) {
    if (json["food_packages_search"] != null) {
      foodPackagesSearch = <FoodPackagesSearch>[];
      json["food_packages_search"].forEach((v) {
        foodPackagesSearch!.add(FoodPackagesSearch.fromJson(v));
      });
    }
  }
}

class FoodPackagesSearch {
  int? foodPackageId;
  String? uniqueId;
  String? subscriptionType;
  String? packageName;
  String? packagePrice;
  String? discountPrice;
  String? salesPrice;
  String? verified;
  int? monthlyPackagePrice;
  int? monthlySalesPrice;
  String? cityName;
  String? isFavorite;
  List<String>? mealTypes;

  FoodPackagesSearch({
    required this.foodPackageId,
    required this.uniqueId,
    required this.subscriptionType,
    required this.packageName,
    required this.packagePrice,
    required this.discountPrice,
    required this.salesPrice,
    required this.monthlyPackagePrice,
    required this.monthlySalesPrice,
    required this.cityName,
    required this.verified,
    required this.mealTypes,
    required this.isFavorite,
  });
  FoodPackagesSearch.fromJson(Map<String, dynamic> json) {
    foodPackageId = json["food_package_id"];
    uniqueId = json["unique_id"];
    subscriptionType = json["subscription_type"];
    packageName = json["package_name"];
    packagePrice = json["package_price"];
    discountPrice = json["discount_price"];
    verified = json["verified"];
    salesPrice = json["sales_price"];
    monthlyPackagePrice = json["monthly_package_price"];
    monthlySalesPrice = json["monthly_sales_price"];
    cityName = json["city_name"];
    isFavorite = json["is_favorite"];
    // discountPrice = json["discount_price"];
    mealTypes = json["meal_types"] != null
        ? List<String>.from(json["meal_types"]!.map((x) => x))
        : null;
  }
}
