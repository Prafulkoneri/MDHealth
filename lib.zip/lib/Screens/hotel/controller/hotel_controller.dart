import 'package:flutter/material.dart';

class HotelController extends ChangeNotifier{}