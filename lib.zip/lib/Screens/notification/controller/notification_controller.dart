import 'package:flutter/material.dart';

class NotificationCOntroller extends ChangeNotifier{}