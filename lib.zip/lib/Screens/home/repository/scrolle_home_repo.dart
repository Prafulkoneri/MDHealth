import 'package:http/http.dart' as http;
import 'package:md_health/Screens/auth/model/city_list_model.dart';
import 'package:md_health/network/end_point.dart';
import 'package:md_health/utils/utils.dart';
import 'package:http/http.dart' as http;
import 'package:md_health/Screens/payment/model/payment_done_model.dart';

import 'dart:developer';

import 'package:md_health/network/end_point.dart';

class HomeScrolleRepo {
  Future<http.Response> homeScrolle(token) async {
    print(Uri.parse(Endpoint.homeScroole));

    try {
      return await http.get(Uri.parse(Endpoint.homeScroole), headers: {
        "Authorization": "Bearer $token",
      });
    } catch (e) {
      throw Exception(e);
    }
  }
}
