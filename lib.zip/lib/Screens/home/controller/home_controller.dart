import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:md_health/Screens/home/model/new_city_for_treatment.dart';
import 'package:md_health/Screens/home/model/new_city_list_model.dart';
import 'package:md_health/Screens/home/model/scrolle_home_nodel.dart';
import 'package:md_health/Screens/home/model/shop_cart_count_model.dart';
import 'package:md_health/Screens/home/model/treatment_list_model.dart';
import 'package:md_health/Screens/home/model/user_model.dart';
import 'package:md_health/Screens/home/repository/new_city_for_treatment.dart';
import 'package:md_health/Screens/home/repository/new_getcityList_repo.dart';
import 'package:md_health/Screens/home/repository/scrolle_home_repo.dart';
import 'package:md_health/Screens/home/repository/shop_cart_count_repo.dart';
import 'package:md_health/Screens/home/repository/treatment_list_repo.dart';
import 'package:md_health/Screens/home/repository/user_repo.dart';
import 'package:md_health/Screens/search/controller/search_view_controller.dart';
import 'package:md_health/Screens/search/view/search_view.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:md_health/Screens/auth/model/city_list_model.dart';
import 'package:md_health/Screens/home/repository/city_list_repository.dart';
import 'package:md_health/Screens/search/model/search_model.dart';
import 'package:md_health/Screens/search/repository/search_view_repository.dart';
import 'package:md_health/utils/utils.dart';

class HomeViewController extends ChangeNotifier {
  // SearchViewRepository packageRepository = SearchViewRepository();
  String selectedText = '';
  String? countryId;
  int? selectedTextIndex = -1; // Assuming -1 represents no selection
  // int? selectedTextIndex1;
  bool isLoading = true;
// void setSelectedText(value, index) {
//   selectedText = value;
//   selectedTextIndex = index;
//   notifyListeners();
// }
  // List<PackageList>? packageList;
  // List<String>? otherServices;
  // CityListRepository cityListRepo = CityListRepository();
  NewCityGetlistRepo newCityGetlistRepo = NewCityGetlistRepo();
  NewCityforTreatmentRepo newCityforTreatmentRepo = NewCityforTreatmentRepo();
  List<PurchaseDetail>? purchaseDetails;

  HomeScrolleRepo homeScrolleRepo = HomeScrolleRepo();

  TreatmentListRepository treatmentListRepo = TreatmentListRepository();
  UserNameRepo userNameRepo = UserNameRepo();

  List<CityListData>? cityList;
  List<bool> radioValue = [true];
  List<NewCityList>? oiginalcityList = [];
  String? fullName;

  String selectedText1 = "";
  String? treatmentName;

  int? selectedTextIndex1 = -1;
  // late SearchViewController packageController;

  // HomeViewController() {
  //   packageController = SearchViewController();
  // }

  Future<void> initState(
    context,
    cId,
  ) async {
    // treatmentName = '';
    selectedTextIndex ?? '';
    // selectedText1 = '';
    selectedTextIndex1 ?? '';
    // getShopCartCount(context);
    userName(context);
    getTreatmentList(context);
    getCities(context);
    notifyListeners();
  }

  void setSelectedText(value, index) {
    selectedText = value;
    selectedTextIndex = index;
    notifyListeners();
  }

  void setSelectedText1(value, index) {
    selectedText1 = value;
    selectedTextIndex1 = index;
    notifyListeners();
  }

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  List<NewCityList>? newCityList;
  Future<void> getCities(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    newCityGetlistRepo
        .newGetlistCity(pref.getString("successToken"))
        .then((response) async {
      // log(response.body);
      debugPrint('/////////////');
      final result =
          GetTreatnentListNewResponse.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        newCityList = result.newCityList;
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  NewCityForRequestModel get newCityForRequestModel =>
      NewCityForRequestModel(treatmentName: treatmentName);
  Future<void> NewCitiestratment(context, tName) async {
    showLoader(true);
    oiginalcityList = newCityList;
    newCityList = [];
    treatmentName = tName.toString();
    SharedPreferences pref = await SharedPreferences.getInstance();
    newCityforTreatmentRepo
        .newCityfortreatment(
            newCityForRequestModel, pref.getString("successToken"))
        .then((response) async {
      // log(response.body);
      debugPrint('/////////////');
      final result =
          GetTreatnentListNewResponse.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        newCityList = result.newCityList;

        showLoader(false);
        notifyListeners();
      } else {
        // newCityList =
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  Future<void> homeScrollePer(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    homeScrolleRepo
        .homeScrolle(pref.getString("successToken"))
        .then((response) async {
      // log(response.body);
      debugPrint('/////////////');
      final result = HomePageScroolResponse.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        purchaseDetails = result.purchaseDetails;
        // treatmentList = result.treatmentList;
        // treatmentList!.map((item) => item.treatmentName).toList();
        // cityList = result.cityList;
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  List<TreatmentList>? treatmentList;

  // Future<void> getCities(context) async {
  //   debugPrint('heyyyy');
  //   cityListRepo.getCityList(requestModel, context).then((response) {
  //     final result = CityListResponseModel.fromJson(jsonDecode(response.body));

  //     if (result.status == 200) {
  //       cityList = result.cityList;
  //       debugPrint("cityList?[1].toString()");
  //       debugPrint(cityList?[1].toString());
  //       notifyListeners();
  //     } else {
  //       Utils.showPrimarySnackbar(context, result.message,
  //           type: SnackType.error);
  //     }
  //   }).onError((error, stackTrace) {
  //     Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
  //   }).catchError(
  //     (Object e) {
  //       Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
  //     },
  //     test: (Object e) {
  //       Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
  //       return false;
  //     },
  //   );
  // }

  Future<void> getTreatmentList(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    treatmentListRepo
        .getTreatmentList(pref.getString("successToken"))
        .then((response) async {
      // log(response.body);
      debugPrint('/////////////');
      final result =
          TreatmentListResponseOdel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        treatmentList = result.treatmentList;
        treatmentList!.map((item) => item.treatmentName).toList();
        // cityList = result.cityList;
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  /////////////////////////////////////
  Future<void> userName(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    userNameRepo
        .userName(pref.getString("successToken"))
        .then((response) async {
      // log(response.body);
      debugPrint('/////////////');
      final result = UserReponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log("////// ${result.fullName}");
        fullName = result.fullName;
        // cityList = result.cityList;
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  ///////////////////////////////////

  // Future<void> getShopCartCount(context) async {
  //   showLoader(true);
  //   SharedPreferences pref = await SharedPreferences.getInstance();
  //   shopCartCountRepo
  //       .cartCount(pref.getString("successToken"))
  //       .then((response) async {
  //     // log(response.body);
  //     debugPrint('/////////////');
  //     final result = ShopCartCountModel.fromJson(jsonDecode(response.body));
  //     if (response.statusCode == 200) {
  //       log("///77777777777777/// ${result.cartCount}");
  //       cartCount = result.cartCount.toString();
  //       // cityList = result.cityList;
  //       showLoader(false);
  //       notifyListeners();
  //     } else {
  //       log(response.body);
  //       Utils.showPrimarySnackbar(context, result.message,
  //           type: SnackType.error);
  //     }
  //   }).onError((error, stackTrace) {
  //     Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
  //   }).catchError(
  //     (Object e) {
  //       Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
  //     },
  //     test: (Object e) {
  //       Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
  //       return false;
  //     },
  //   );
  // }
}
