import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:md_health/Screens/home/controller/home_controller.dart';
import 'package:md_health/Screens/home/view/custome_select_treatemnet_box.dart';
import 'package:md_health/Screens/search/view/search_view.dart';
import 'package:md_health/Screens/home/view/custom_select_box.dart';
import 'package:md_health/test_widget.dart';
import 'package:provider/provider.dart';
import '../../../constants/styles/textstyle.dart';
import '../../../widget/buttons.dart';

class HomeScreenSectionOne extends StatefulWidget {
  const HomeScreenSectionOne({super.key});

  @override
  State<HomeScreenSectionOne> createState() => _HomeScreenSectionOneState();
}

class _HomeScreenSectionOneState extends State<HomeScreenSectionOne>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    _animationController = AnimationController(
      vsync: this,
      duration:
          const Duration(milliseconds: 500), // Adjust the duration as needed
    );
    _animation = Tween<double>(begin: 1, end: 0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.linear),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

/////////////////Last//////////////////
  void _showDialog() {
    debugPrint('helooooooooooooooooooo');
    _animationController.reset();
    _animationController.forward();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        final watch = context.watch<HomeViewController>();
        final read = context.read<HomeViewController>();
        return AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(
                  0, MediaQuery.of(context).size.height * _animation.value),
              child: CustomSelectBox(
                list: watch.newCityList!.map((item) => item.cityName).toList(),
                title: const SelectBoxText(
                  text: 'Choose your treatment city',
                  fontWeight: FontWeight.w700,
                ),
                tapFun: () {
                  debugPrint('/////////////////////////helooo//////');
                },
                button: true,
                submitActionFnction: () {
                  Navigator.pop(context);
                  // _animationController.reverse();
                },
              ),
            );
          },
        );
      },
    );
  }

  //////////////////////////////////
  void _showDialog1() {
    debugPrint('helooooooooooooooooooo');
    _animationController.reset();
    _animationController.forward();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        final watch = context.watch<HomeViewController>();
        final read = context.read<HomeViewController>();
        return AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(
                  0, MediaQuery.of(context).size.height * _animation.value),
              child: CustomSelectBoxTreatment(
                list: watch.treatmentList!
                    .map((item) => item.treatmentName)
                    .toList(),
                title: const SelectBoxText(
                  text: 'Choose your treatment',
                  fontWeight: FontWeight.w700,
                ),
                tapFun: () {
                  read.NewCitiestratment(context, watch.treatmentName);
                  debugPrint('///ALIIII////');
                },
                button: true,
                submitActionFnction: () {
                  Navigator.pop(context);
                  // _animationController.reverse();
                },
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final watch = context.watch<HomeViewController>();
    final read = context.read<HomeViewController>();
    return Column(
      children: [
        Center(
          child: Text(
            "PLAN YOUR TREATMENT",
            style: TextStyle(
                fontFamily: 'Campton',
                color: const Color(0xff4CDB06),
                fontSize: 25.sp,
                fontWeight: FontWeight.w700),
          ),
        ),
        Text(
          "NOW",
          style: TextStyle(
              fontFamily: 'Campton',
              color: Colors.white,
              fontSize: 72.sp,
              fontWeight: FontWeight.w700),
        ),
        SizedBox(
          height: 10.h,
        ),
        const HomeSectionText(
          text: "Choose your treatment city",
        ),
        SizedBox(
          height: 25.h,
        ),
        Card(
          surfaceTintColor: Colors.blue,
          color: Colors.transparent,
          shape: const RoundedRectangleBorder(
            side: BorderSide(color: Colors.white),
            borderRadius: BorderRadius.all(
              Radius.circular(30),
            ),
          ),
          child: GestureDetector(
            onTap: () {
              debugPrint('/////////////');
              if (watch.newCityList != null) {
                _showDialog1();
              } else {
                //show alert
                //no internet
              }
            },
            child: Container(
              color: Colors.transparent,
              height: 45.h,
              width: MediaQuery.of(context).size.width * 0.82,
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  HomeSectionText(
                      // text: 'istanbul',
                      text: watch.selectedTextIndex1 != -1
                          ? watch.selectedText1
                          : "Treatment"),
                  SvgPicture.asset(
                    'assets/icons/iconamoon_arrow-up-2.svg',
                    color: Colors.white,
                  )
                ],
              ),
            ),
          ),
        ),
        SizedBox(
          height: 10.h,
        ),
        Card(
          surfaceTintColor: Colors.blue,
          color: Colors.transparent,
          shape: const RoundedRectangleBorder(
            side: BorderSide(color: Colors.white),
            borderRadius: BorderRadius.all(
              Radius.circular(30),
            ),
          ),
          child: GestureDetector(
            onTap: () {
              debugPrint('/////////////');
              if (watch.newCityList != null) {
                _showDialog();
              } else {
                //show alert
                //no internet
              }
            },
            child: Container(
              color: Colors.transparent,
              height: 45.h,
              width: MediaQuery.of(context).size.width * 0.82,
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  HomeSectionText(
                    // text: 'istanbul',
                    // text: watch.selectedText!,
                    text: watch.selectedTextIndex != -1
                        ? watch.selectedText
                        : 'City', // Only display selected text if it's selected
                  ),
                  SvgPicture.asset(
                    'assets/icons/iconamoon_arrow-up-2.svg',
                    color: Colors.white,
                  )
                ],
              ),
            ),
          ),
        ),
        SizedBox(
          height: 14.h,
        ),
        PrimaryButton(
          color: const Color(0xff4CDB06),
          onTap: () {
            print(watch.selectedText1);
            print(watch.selectedText);
            // return;
            Navigator.push(
              context,
              SlidePageRoute(
                page: SearchView(
                  treatmentName: watch.selectedText1,
                  // refresh: false,
                  cityName: watch.selectedText,
                  platformType: "android",
                ),
                direction:
                    SlideDirection.right, // Specify the slide direction here
                // delay: Duration(milliseconds: 2000),
              ),
            );
          },
          height: 50,
          width: MediaQuery.of(context).size.width * 0.82,
          borderRadius: 30,
          child: Text(
            'Search',
            style: TextStyle(
              fontFamily: 'Campton',
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.black,
            ),
          ),
        ),
        SizedBox(
          height: 50.h,
        )
      ],
    );
  }
}

Widget _circle() {
  return Container(
    height: 150,
    width: 150,
    decoration: const BoxDecoration(
      shape: BoxShape.circle,
      color: Color(0xff4CDB06),
    ),
  );
}
