import 'package:flutter/material.dart';

import '../../../widget/image_holder.dart';

class EarningImagePercentage extends StatelessWidget {
  const EarningImagePercentage({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: EdgeInsets.only(left: 15),
        child: Row(
          children: [
            ImageHolder(
              amount: '2',
              imageUrl: 'assets/images/Rectangle_6.png',
              description:
                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            ),
            ImageHolder(
              amount: '4',
              imageUrl: 'assets/images/Rectangle_7.png',
              description:
                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            ),
            ImageHolder(
              amount: '2',
              imageUrl: 'assets/images/Rectangle_6.png',
              description:
                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            ),
            ImageHolder(
              amount: '4',
              imageUrl: 'assets/images/Rectangle_7.png',
              description:
                  'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            ),
          ],
        ),
      ),
    );
  }
}
