class FillFormViewHomeRequestModel {
  String? firstName;
  String? lastName;
  String? email;
  String? country;
  String? contactNumber;
  String? treatmentName;
  String? priviousTreatment;
  String? details;
  String? whyNeedTreatment;
  String? travelVisa;
  String? treatmentImagePath;

  FillFormViewHomeRequestModel({
    this.firstName,
    this.lastName,
    this.email,
    this.contactNumber,
    this.country,
    this.treatmentName,
    this.priviousTreatment,
    this.details,
    this.whyNeedTreatment,
    this.travelVisa,
    this.treatmentImagePath,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data["first_name"] = firstName;
    data["last_name"] = lastName;
    data["email"] = email;
    data["contact_no"] = contactNumber;
    data["country"] = country;
    data["treatment_name"] = treatmentName;
    data["details"] = details;
    data["why_do_you_need_treatment"] = whyNeedTreatment;
    data["previous_treatment"] = priviousTreatment;
    data["travel_visa"] = travelVisa;
    data["treatment_image_path"] = treatmentImagePath;

    return data;
  }
}

////////////////////////////////RESP{ONSE/////////////////////////////}
class FillFormResponseMOdelView {
  int? status;
  String? message;

  FillFormResponseMOdelView({
    required this.status,
    required this.message,
  });
  FillFormResponseMOdelView.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
  }
}
