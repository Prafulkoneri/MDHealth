import 'dart:convert';
import 'dart:developer';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:md_health/Screens/bank_transfer/model/bank_detai_model.dart';
import 'package:md_health/Screens/bank_transfer/model/get_bank_trasfer_model.dart';
import 'package:md_health/Screens/bank_transfer/repository/detail_bank_repo.dart';
import 'package:md_health/Screens/bank_transfer/repository/get_bank_trasfer_repo.dart';
import 'package:md_health/Screens/card_diet/model/card_diet_payment_model.dart';
import 'package:md_health/Screens/card_diet/repository/card_diet_repo.dart';
import 'package:md_health/Screens/card_diet/view/payment_processing.dart';
import 'package:md_health/Screens/payment/model/payment_done_model.dart';
import 'package:md_health/Screens/payment/model/payment_purches_model.dart';
import 'package:md_health/Screens/payment/repository/cart_payment_repo.dart';
import 'package:md_health/Screens/payment/repository/payment_done_repo.dart';
import 'package:md_health/Screens/payment/view/Payment_processing_view.dart';
import 'package:md_health/Screens/payment_details/model/md_coin_model.dart';
import 'package:md_health/Screens/payment_details/repository/wallet_repo.dart';
import 'package:md_health/Screens/shop_payment/model/shop_payment_model.dart';
import 'package:md_health/Screens/shop_payment/repository/shop_card_repo.dart';
import 'package:md_health/test_widget.dart';
import 'package:md_health/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PaymentController extends ChangeNotifier {
  PaymentDetailslastRepository paymentDetailslastRepository =
      PaymentDetailslastRepository();
  PaymentDoneRepo paymentDoneRepo = PaymentDoneRepo();
  MdCoinRepo mdCoinRepo = MdCoinRepo();
  PAymentDoneShopRepo paymentDoneShopRepo = PAymentDoneShopRepo();
  TextEditingController passwordController = TextEditingController();
  TextEditingController transactionIdController = TextEditingController();

// PaymentDoneRepo
  OrderId? orderId;
  bool isLoading = false;
  String packageId = "";
  String patientID = "";
  String purchesId = "";
  String percentage = "";
  String purchaseType = "";
  List<String>? otherService;
  String price = "";
  String pripaymentTypece = "";
  String salePrice = "";
  String paidAmount = "";
  String randomNumber = '';
  bool showBack = false;
  FocusNode cvvFocusNode = FocusNode();

  PurchaseDetailsDataLast? purchaseDetailsDataLast;
  List<OtherService>? otherServices;

  Future<void> initState(context, pId, sPrice, priceP, percentagePrices,
      oServices, purchesId, patientID, purcType, bname, pName) async {
    cardNameController.clear();
    accountNumberController.clear();
    expiryFieldCtrl.clear();
    cvvController.clear();
    expiryDate = '';
    walletCount(context);
    transactionIdController.clear();
    await getBankList(context);
    formattedAccountNumber = '';
    nameaccount = '';
    // await bakDetails(
    //   context,
    //   pId,
    //   bname,
    // );
    formattedAccountNumber = "1234 1234 1234 1234";
    nameaccount = "John Smith";
    expiryDate = "MM / YY";
    cvvn = "***";
    print("objectttt");
    print(pId);
    print("objectttt");
    await getPaymentDetailsList(
        context, pId, sPrice, priceP, percentagePrices, oServices, purcType);
    notifyListeners();
  }

  TextEditingController cvvController = TextEditingController();
  PurchaseDetailsRequestModel get purchaseDetailsRequestModel =>
      PurchaseDetailsRequestModel(
        purchaseType: purchaseType.toString(),
        purchesId: "0",
        packageId: packageId.toString(),
        salePrice: salePrice,
        price: price,
        percentage: percentage,
        otherService: otherService,
      );
  Future<void> getPaymentDetailsList(context, pId, sPrice, priceP,
      percentagePrices, oServices, purcType) async {
    packageId = pId.toString();
    salePrice = sPrice.toString();
    price = priceP;
    percentage = percentagePrices;
    otherService = oServices;
    purchaseType = purcType;
    SharedPreferences pref = await SharedPreferences.getInstance();
    paymentDetailslastRepository
        .getPaymentDetailsList(
            purchaseDetailsRequestModel, pref.getString("successToken"))
        .then((response) async {
      // print(response.body);
      debugPrint('/////////////');
      final result =
          LastPurchaseDetailsResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        print(response.body);
        purchaseDetailsDataLast = result.purchaseDetailsDataLast;
        otherServices = result.otherServices;

        notifyListeners();
      } else {
        print(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

// var random = Random();

//  (random.nextInt(900000000) + 100000000).toString();

  PaymentDoneRequestModel get paymentDoneRequestModel =>
      PaymentDoneRequestModel(
        conversationId: randomNumber.toString(),
        otherService: otherService,
        purchaseType: purchaseType,
        patientID: patientID,
        purchesId: purchesId,
        paymentMethod: "card",
        packageId: packageId.toString(), //
        paidAmount: price, //
        salePrice: salePrice, //
        percentage: percentage, //
        platFormType: "android", //
      );
  Future<void> paymentDone(context, purcheIdN, idPatient, purcType, oServices,
      paymentType, randNumber) async {
    purchesId = purcheIdN;
    patientID = idPatient;
    purchaseType = purcType;
    otherService = oServices;
    paymentType = paymentType;
    randomNumber = randNumber.toString();
    print("yguytggytyttyftyty");
    print(randomNumber);
    print("yguytggytyttyftyty");
    SharedPreferences pref = await SharedPreferences.getInstance();
    paymentDoneRepo
        .paymentdone(paymentDoneRequestModel, pref.getString("successToken"))
        .then((response) async {
      // print(response.body);
      debugPrint('/////////////');
      final result =
          PaymentDoneResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        print(response.body);
        orderId = result.orderId;
        notifyListeners();
      } else {
        print(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  String? coins;
////////////////////////////////////////////////////
  Future<void> walletCount(context) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    mdCoinRepo
        .mdCoinWallet(pref.getString("successToken"))
        .then((response) async {
      // print(response.body);
      debugPrint('/////////////');
      final result = GetMdCoinsResponse.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        print(response.body);
        coins = result.coins;
        notifyListeners();
      } else {
        print(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  String? _expiryErrorText;

  // Getter for expiryErrorText
  String? get expiryErrorText => _expiryErrorText;

  // Setter for expiryErrorText
  set expiryErrorText(String? value) {
    _expiryErrorText = value;
    notifyListeners(); // If PaymentController extends ChangeNotifier
  }

///////////////////////////////////////////////////
  TextEditingController expiryFieldCtrl = TextEditingController();
  String formattedAccountNumber = "1234 1234 1234 1234";
  String nameaccount = "John Smith";
  // String expir = "12/24";
  String cvvn = "";
  String expiryDate = 'MM/YY';
  // void accountNumver(String newText) {
  //   number = newText;
  //   notifyListeners();
  // }
  void accountNumver(String newText) {
    formattedAccountNumber = newText;
    notifyListeners();
  }

  TextEditingController cardNameController = TextEditingController();
  void accountName(String newText) {
    nameaccount = newText;
    notifyListeners();
  }

  void accountexpire(String newText) {
    expiryDate = newText;
    notifyListeners();
  }

  void accountcvv(String newText) {
    cvvn = newText;
    notifyListeners();
  }

  TextEditingController accountNumberController = TextEditingController();
  formatAccountNumber() {
    String accountNumber =
        accountNumberController.text.replaceAll(RegExp(r'\s'), '');
    if (accountNumber.length >= 4) {
      accountNumber = accountNumber.replaceAllMapped(
          RegExp(r".{4}"), (match) => "${match.group(0)} ");
    }
    formattedAccountNumber = accountNumber.trim();
    notifyListeners();
  }

  //////////////////
  void clearAccountNumber() {
    accountNumberController.clear();
    formattedAccountNumber = '';
    notifyListeners();
  }

  // String formatAccountNumber(String accountNumber) {
  //   accountNumber = accountNumber.replaceAllMapped(
  //       RegExp(r".{4}"), (match) => "${match.group(0)} ");

  //   return accountNumber.trim();
  // }

  String getCardType(String accountNumber) {
    if (RegExp(r'[4]').hasMatch(accountNumber)) {
      return 'assets/images/ri_visa-line.png';
    } else if (RegExp(
            r'((5[1-5])|(222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720))')
        .hasMatch(accountNumber)) {
      return 'assets/images/mastercard.png';
    } else if (RegExp(r'((6[45])|(6011))').hasMatch(accountNumber)) {
      return 'assets/images/american-express.png';
    } else if (RegExp(r'^6(?:011|5[0-9]{2})[0-9]{12}$')
        .hasMatch(accountNumber)) {
      return 'assets/images/discover.png';
    } else if (RegExp(r'((30[0-5])|(3[89])|(36)|(3095))')
        .hasMatch(accountNumber)) {
      return 'assets/images/dinners.png';
    } else if (RegExp(r'(352[89]|35[3-8][0-9])').hasMatch(accountNumber)) {
      return 'assets/images/ri_visa-line.png';
    } else {
      return 'assets/images/ri_visa-line.png';
    }
  }

  String cardTypes = '';
  String accountNumbers = '';

  String get cardType => cardTypes;
  String get accountNumber => accountNumbers;

  void updateCardType() {
    cardTypes = getCardType((formattedAccountNumber));
    notifyListeners();
  }

  void updateAccountNumber(String newAccountNumber) {
    accountNumbers = newAccountNumber;
    updateCardType(); // Call updateCardType when the account number changes
    notifyListeners();
  }

  bool isValidCVV(String cvv) {
    return cvv.length == 3 || cvv.length == 4;
  }

  ////////////////////////////////////////

  int? countryListId;

  Future<void> onSelectCountryType(int value) async {
    countryListId = value;
    print(countryListId);
    notifyListeners();
  }

  List<BankList>? bankList;
  Future<void> getBankList(context) async {
    if (transactionIdController.text == '') {
      Utils.showPrimarySnackbar(context, 'Please enter trancaction id',
          type: SnackType.error);
      notifyListeners();
    }
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    getBanklistRepo.bankList(pref.getString("successToken")).then((response) {
      print(response.body);
      final result = BankListModel.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          bankList = result.bankList;

          showLoader(false);
          Utils.showPrimarySnackbar(context, "", type: SnackType.success);
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, "", type: SnackType.error);
        }
      } else {
        Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  GetBanklistRepo getBanklistRepo = GetBanklistRepo();
  BankListDetailRepo bankListDetailRepo = BankListDetailRepo();
  // CompletedPackageRepo completedPackageRepo = CompletedPackageRepo();
  String? bankName;

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  //////////////////////////////////////////////
  BankDetails? bankDetails;
  PackageDetails? packageDetails;
  BankListRequestModel get bankListRequestModel => BankListRequestModel(
        packageID: packageId.toString(),
        bankId: countryListId.toString(),
      );
  Future<void> bakDetails(context, bname, pId) async {
    bankName = bname.toString();
    packageId = pId.toString();
    showLoader(true);

    SharedPreferences pref = await SharedPreferences.getInstance();
    bankListDetailRepo
        .bankListdetail(bankListRequestModel, pref.getString("successToken"))
        .then((response) async {
      // print(response.body);
      debugPrint('/////////////');
      final result = BankListModelRsponse.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        print(response.body);
        bankDetails = result.bankDetails;
        packageDetails = result.packageDetails;
        print("juhujkiuyol,oi;l");
        showLoader(false);
        notifyListeners();
      } else {
        print(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
  ///////////////////////////////////////FOOD/////////////////////////////

  String type = "";
  String data = "";
  String startDate = "";
  String endDate = "";
  String platformtype = "";
  String subscriptiontype = "";
  String paymentMethod = "";
  // String foodPackageTotalPrice = "";
  String foodPackageTotalPrice = ""; // Change data type to String

  String foodPackageId = "";
  DietCardPAymentRepo dietCardPAymentRepo = DietCardPAymentRepo();
  String? shopOrderID;

  CardDietPaymentRequest get cardDietPaymentRequest => CardDietPaymentRequest(
      transactionId: transactionIdController.text,
      subscriptionType: subscriptiontype,
      mdCoins: data,
      type: type,
      subscriptionStartDate: startDate,
      subscriptionEndDate: endDate,
      platformtype: "android",
      paymentMethod: paymentMethod,
      foodPackageTotalPrice: foodPackageTotalPrice,
      foodPackageId: foodPackageId);
  Future<void> cardDietPayment(context, moType, sDate, eDate, ptype, pMethod,
      fpTotalPrices, fpId, mcoin, subscType, transId) async {
    type = moType.toString();
    data = mcoin.toString();
    startDate = sDate.toString();
    endDate = eDate.toString();
    platformtype = ptype.toString();
    paymentMethod = pMethod.toString();
    foodPackageTotalPrice = fpTotalPrices.toString();
    foodPackageId = fpId.toString();
    subscriptiontype = subscType.toString();
    transactionIdController.text = transId.toString();

    showLoader(true);

    SharedPreferences pref = await SharedPreferences.getInstance();
    dietCardPAymentRepo
        .cardDietPaymnet(cardDietPaymentRequest, pref.getString("successToken"))
        .then((response) async {
      debugPrint('/////////////');
      final result =
          CardDietPaymentResponse.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        print(response.body);
        shopOrderID = result.shopOrderID;
        showLoader(false);
        notifyListeners();
        // }
      } else {
        print(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  //////////////////////////ShopCardPayment////////////////////////
  //  BankListRequestModel get bankListRequestModel => BankListRequestModel(
  //       packageID: packageId.toString(),
  //       bankId: countryListId.toString(),
  //     );
  String? orderIdsho;

  Future<void> shopCardPayment(context) async {
    showLoader(true);

    SharedPreferences pref = await SharedPreferences.getInstance();
    paymentDoneShopRepo
        .paymentDoneShop(pref.getString("successToken"))
        .then((response) async {
      // print(response.body);
      debugPrint('/////////////');
      final result =
          ShopCardPaymentResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        print(response.body);
        orderIdsho = result.orderIdsho;
        print("juhujkiuyol,oi;l");
        showLoader(false);
        notifyListeners();
      } else {
        print(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
}
