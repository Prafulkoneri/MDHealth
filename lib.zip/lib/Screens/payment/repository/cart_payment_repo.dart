// import 'package:http/http.dart' as http;
// import 'package:md_health/Screens/auth/model/signup_response_model.dart';
// import 'package:md_health/Screens/payment_details/model/payment_details_model.dart';
// import 'package:md_health/network/end_point.dart';
// import 'package:md_health/utils/utils.dart';

// class PaymentDetailsRepository {
//   Future<http.Response> getPaymentDetailsList(
//       PaymentDetailRequestModel reqModel, context) async {
//     try {
//       print(reqModel.toJson());
//       return await http.post(Uri.parse(Endpoint.mdCustomerPackagePurchaseDetails),
//           body: reqModel.toJson());
//     } catch (e) {
//       Utils.showPrimarySnackbar(context, e, type: SnackType.error);
//       throw Exception(e);
//     }
//   }
// }

// import 'dart:convert';

// import 'package:http/http.dart' as http;
// import 'package:md_health/Screens/payment/model/payment_purches_model.dart';

// import 'dart:developer';

// import 'package:md_health/network/end_point.dart';

// class GetLastPaymentRepo {
//   Future<http.Response> getPaymentDetailsList(
//       PurchaseDetailsRequestModel reqModel, token) async {
//     print(Uri.parse(Endpoint.getPurchesInformation));
//     log("${reqModel.toJson()}ni yuythgbioyu5wihounoijplikmo");
//     try {
//       return await http.post(Uri.parse(Endpoint.getPurchesInformation),
//           body: jsonEncode(reqModel.toJson()),
//           // reqModel.toJson(),
//           headers: {
//             "Authorization": "Bearer $token",
//           });
//     } catch (e) {
//       throw Exception(e);
//     }
//   }
// }

import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:md_health/Screens/payment/model/payment_purches_model.dart';

import 'dart:developer';

import 'package:md_health/network/end_point.dart';

class PaymentDetailslastRepository {
  Future<http.Response> getPaymentDetailsList(
      PurchaseDetailsRequestModel reqModel, token) async {
    print(reqModel.toJson());

    print(Uri.parse(Endpoint.getPurchesInformation));
    log("${reqModel.toJson()}");

    try {
      return await http.post(Uri.parse(Endpoint.getPurchesInformation),
          body: reqModel.toJson(),
          headers: {
            "Authorization": "Bearer $token",
          });
    } catch (e) {
      throw Exception(e);
    }
  }
}
