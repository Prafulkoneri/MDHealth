import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:md_health/Screens/favourt/model/fav_count_model.dart';
import 'package:md_health/Screens/favourt/model/fav_list_Detail_view.dart';
import 'package:md_health/Screens/favourt/model/remoe_food_model.dart';
import 'package:md_health/Screens/favourt/model/remove_fav_packge_model.dart';
import 'package:md_health/Screens/favourt/repository/fav_count_repo.dart';
import 'package:md_health/Screens/favourt/repository/fav_list_detail_repo.dart';
import 'package:md_health/Screens/favourt/repository/remove_food_fav_repo.dart';
import 'package:md_health/Screens/favourt/repository/remove_pack_repo.dart';
import 'package:md_health/Screens/favourt/view/favt_list.dart';
import 'package:md_health/Screens/order/model/order_count_model.dart';
import 'package:md_health/Screens/order/model/shop_countOrder.dart';
import 'package:md_health/Screens/order/repository/order_count_repo.dart';
import 'package:md_health/Screens/order/repository/shop_orderCount_repo.dart';
import 'package:md_health/test_widget.dart';
import 'package:md_health/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DietOrderCountController extends ChangeNotifier {
  OrderCountRepo orderCountRepo = OrderCountRepo();
  ShopCountOrderRepo shopCountOrderRepo = ShopCountOrderRepo();
  int? orderCount;
  int? shopOrderCount;

  bool isLoading = true;
  AddFavCount? addCount;
  List<FavDetailViewList>? favdetailViewList;

  Future<void> initState(context) async {
    await foodOrderCount(context);
    await shoOrderCount(context);
    notifyListeners();
  }

/////////////////////////////

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  Future<void> foodOrderCount(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    orderCountRepo.orderCount(pref.getString("successToken")).then((response) {
      log(response.body);
      final result = OrderCountResponseModel.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          orderCount = result.orderCount;
          showLoader(false);
          notifyListeners();
          notifyListeners();
        } else {
          // Utils.showPrimarySnackbar(context, "", type: SnackType.error); //
        }
      } else {
        // Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    });
  }
  //////////////////////////////////////////////////

  Future<void> shoOrderCount(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    shopCountOrderRepo
        .shopCountO(pref.getString("successToken"))
        .then((response) {
      log(response.body);
      final result = ShopCountResponseModel.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          shopOrderCount = result.shopOrderCount;
          showLoader(false);
          notifyListeners();
          notifyListeners();
        } else {
          // Utils.showPrimarySnackbar(context, "", type: SnackType.error); //
        }
      } else {
        // Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    });
  }
}
