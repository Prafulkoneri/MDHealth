class GetProfileRequestModel {
  String? firstName;
  String? lastName;
  String? email;
  String? phone;
  String? countryId;
  String? cityId;
  String? address;

  GetProfileRequestModel({
    this.firstName,
    this.lastName,
    this.email,
    this.phone,
    this.countryId,
    this.cityId,
    this.address,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data["first_name"] = firstName;
    data["last_name"] = lastName;
    data["email"] = email;
    data["phone"] = phone;
    data["country_id"] = countryId;
    data["city_id"] = cityId;
    data["address"] = address;
    return data;
  }
}

////////////////////////////////RESP{ONSE/////////////////////////////}
class GetProfileResponseModel {
  int? status;
  String? message;

  GetProfileResponseModel({
    required this.status,
    required this.message,
  });
  GetProfileResponseModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
  }
}
