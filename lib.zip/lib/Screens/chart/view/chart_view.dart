import 'package:flutter/material.dart';
import 'package:md_health/widget/base_screen.dart';

class ChartScreen extends StatelessWidget {
  const ChartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height ,
        child: Center(child: Text('Chart Screen', style: TextStyle(fontSize: 40,color: Colors.white),)),
      ),
    );
  }
}
