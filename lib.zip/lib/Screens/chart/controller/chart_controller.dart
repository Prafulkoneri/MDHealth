import 'package:flutter/material.dart';

class ChartController extends ChangeNotifier{}