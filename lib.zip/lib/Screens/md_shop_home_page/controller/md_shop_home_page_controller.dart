import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:md_health/Screens/home/model/shop_cart_count_model.dart';
import 'package:md_health/Screens/home/repository/shop_cart_count_repo.dart';
import 'package:md_health/Screens/md_shop_home_page/model/md_banner_model.dart';
import 'package:md_health/Screens/md_shop_home_page/model/md_shop_home_page_model.dart';
import 'package:md_health/Screens/md_shop_home_page/repository/md_banner_repo.dart';
import 'package:md_health/Screens/md_shop_home_page/repository/md_shop_home_page_repo.dart';
import 'package:md_health/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MdShopHomePageController extends ChangeNotifier {
  ShopHomePageRepo shopHomePageRepo = ShopHomePageRepo();
  ShopBannerRepo shopBannerRepo = ShopBannerRepo();

  bool isLoading = true;
  List<FeaturedProduct>? featuredProducts;

  Future<void> initState(context) async {
    await getShopCartCount(context);
    await shopHomePage(context);
    await shopbanner(context);
    notifyListeners();
  }

/////////////////////////////

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  String? cartCount;
  ShopCartCountRepo shopCartCountRepo = ShopCartCountRepo();

  Future<void> getShopCartCount(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    shopCartCountRepo
        .cartCount(pref.getString("successToken"))
        .then((response) async {
      // log(response.body);
      debugPrint('/////////////');
      final result = ShopCartCountModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log("///77777777777777/// ${result.cartCount}");
        cartCount = result.cartCount.toString() ?? "";
        // cityList = result.cityList;
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  Future<void> shopHomePage(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    shopHomePageRepo
        .shopHomepage(pref.getString("successToken"))
        .then((response) {
      log(response.body);
      final result = ShopHomeResmodel.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          featuredProducts = result.featuredProducts;

          showLoader(false);
          Utils.showPrimarySnackbar(context, "", type: SnackType.success);
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, "", type: SnackType.error); //
        }
      } else {
        Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  //////////////////////////////////////////////////////////
  SuperFeaturedProduct? superFeaturedProduct;

  Future<void> shopbanner(context) async {
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    print(pref.getString("successToken"));
    shopBannerRepo.shopBanner(pref.getString("successToken")).then((response) {
      log(response.body);
      final result = ShopOwnerBannerResponseMOdel.fromJson(
        jsonDecode(response.body),
      );
      if (response.statusCode == 200) {
        if (result.status == 200) {
          superFeaturedProduct = result.superFeaturedProduct;
          showLoader(false);
          Utils.showPrimarySnackbar(context, "", type: SnackType.success);
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, "", type: SnackType.error); //
        }
      } else {
        Utils.showPrimarySnackbar(context, "", type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
}
