// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:md_health/Screens/bottom_navigation/controller/bottom_controller.dart';
// import 'package:md_health/Screens/favourt/view/health_favt_pa_list_details.dart';
// import 'package:md_health/Screens/main/controller/main_screen_controller.dart';
// import 'package:md_health/Screens/order_details/view/md_food_view.dart';
// import 'package:md_health/Screens/order_details/view/md_home_view.dart';
// import 'package:md_health/Screens/order_details/view/md_shop_view.dart';
// import 'package:md_health/Screens/packages/view/packages_view.dart';
// import 'package:md_health/test_widget.dart';
// import 'package:md_health/widget/custom_appbar.dart';
// import 'package:md_health/widget/drawer.dart';
// import 'package:provider/provider.dart';

// class PurchesItemView extends StatefulWidget {
//   const PurchesItemView({super.key});

//   @override
//   State<PurchesItemView> createState() => _PurchesItemViewState();
// }

// class _PurchesItemViewState extends State<PurchesItemView> {
//   @override
//   Widget build(BuildContext context) {
//     final read = context.read<NewMainScreenController>();
//     final watch = context.watch<NewMainScreenController>();
//     return Container(
// height: ScreenUtil().screenHeight,
// color: Colors.white,
//         child: SingleChildScrollView(
//             child: Column(children: [
//           // SizedBox(
//           //   height: 48.w,
//           // ),
//           // Container(
//           //   // margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 38.w),
//           //   child: ListView.builder(
//           //     shrinkWrap: true,
//           //     physics: NeverScrollableScrollPhysics(),
//           //     itemCount: 9,
//           //     itemBuilder: (context, index) {
//           //       return GestureDetector(
//           //         onTap: () {
//           //           Navigator.push(
//           //             context,
//           //             MaterialPageRoute(builder: (context) => PackageSView()),
//           //           );
//           //           //
//           //         },
//           //         child: Container(
//           //           padding: EdgeInsets.only(
//           //             left: 18.w,
//           //             right: 18.w,
//           //           ),
//           //           child: Column(
//           //             children: [
//           //               // SizedBox(
//           //               //   height: 100,
//           //               // ),

//           //               SizedBox(
//           //                 height: 20.h,
//           //               ),
//           //             ],
//           //           ),
//           //         ),
//           //       );
//           //     },
//           //   ),
//           // ),
//           GestureDetector(
//             onTap: () {
//               Navigator.push(
//                 context,
//                 SlidePageRoute(
//                   page: PackageSView(
//                       // packageId:MdShopView
//                       //     widget.packageId,
//                       ),
//                   direction:
//                       SlideDirection.right, // Specify the slide direction here
//                   delay: Duration(milliseconds: 5000),
//                 ),
//               );
//             },
//             child: Container(
//               margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 20.w),
//               padding: EdgeInsets.only(
//                   left: 20.w, right: 30.w, top: 17.w, bottom: 18.w),
//               decoration: BoxDecoration(
//                   color: Color(0xffFBFBFB),
//                   borderRadius: BorderRadius.circular(10),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.10),
//                       // offset: Offset(2, 2),
//                       blurRadius: 20,
//                     ),
//                   ]),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Row(
//                     children: [
//                       Image.asset(
//                         "assets/images/black_favourt.png",
//                         width: 35.w,
//                         height: 27.w,
//                       ),
//                       SizedBox(
//                         width: 10.h,
//                       ),
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           RichText(
//                             text: TextSpan(
//                               text: 'MD',
//                               style: TextStyle(
//                                   fontFamily: 'Campton',
//                                   color: Colors.black,
//                                   fontSize: 16.sp,
//                                   fontWeight: FontWeight.w600),

//                               /*defining default style is optional */
//                               children: <TextSpan>[
//                                 TextSpan(
//                                   text: 'health',
//                                   style: TextStyle(
//                                       fontFamily: 'Campton',
//                                       color: Colors.black,
//                                       fontSize: 19.sp,
//                                       fontWeight: FontWeight.w400),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           RichText(
//                             text: TextSpan(
//                               text: 'Purchase',
//                               style: TextStyle(
//                                   fontFamily: 'Campton',
//                                   color: Colors.black,
//                                   fontSize: 15.sp,
//                                   fontWeight: FontWeight.w500),

//                               /*defining default style is optional */
//                               children: <TextSpan>[
//                                 TextSpan(
//                                   text: ' (2)',
//                                   style: TextStyle(
//                                       fontFamily: 'Campton',
//                                       color: Colors.black,
//                                       fontSize: 15.sp,
//                                       fontWeight: FontWeight.w700),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                   SvgPicture.asset("assets/icons/forword.svg"),
//                 ],
//               ),
//             ),
//           ),
//           GestureDetector(
//             onTap: () {
//               Navigator.push(
//                 context,
//                 SlidePageRoute(
//                   page: MdFoodView(
//                       // packageId:MdShopView
//                       //     widget.packageId,
//                       ),
//                   direction:
//                       SlideDirection.right, // Specify the slide direction here
//                   delay: Duration(milliseconds: 5000),
//                 ),
//               );
//             },
//             child: Container(
//               margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 20.w),
//               padding: EdgeInsets.only(
//                   left: 20.w, right: 30.w, top: 17.w, bottom: 18.w),
//               decoration: BoxDecoration(
//                   color: Color(0xffFBFBFB),
//                   borderRadius: BorderRadius.circular(10),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.10),
//                       // offset: Offset(2, 2),
//                       blurRadius: 20,
//                     ),
//                   ]),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Row(
//                     children: [
//                       SvgPicture.asset(
//                         "assets/icons/fluent-mdl2_shop.svg",
//                         width: 35.w,
//                         height: 40.w,
//                       ),
//                       // Image.asset(
//                       //   "assets/images/black_favourt.png",
//                       //   width: 35.w,
//                       //   height: 27.w,
//                       // ),
//                       SizedBox(
//                         width: 10.h,
//                       ),
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           RichText(
//                             text: TextSpan(
//                               text: 'MD',
//                               style: TextStyle(
//                                   fontFamily: 'Campton',
//                                   color: Colors.black,
//                                   fontSize: 16.sp,
//                                   fontWeight: FontWeight.w600),

//                               /*defining default style is optional */
//                               children: <TextSpan>[
//                                 TextSpan(
//                                   text: 'shop',
//                                   style: TextStyle(
//                                       fontFamily: 'Campton',
//                                       color: Colors.black,
//                                       fontSize: 19.sp,
//                                       fontWeight: FontWeight.w400),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           RichText(
//                             text: TextSpan(
//                               text: 'Purchase',
//                               style: TextStyle(
//                                   fontFamily: 'Campton',
//                                   color: Colors.black,
//                                   fontSize: 15.sp,
//                                   fontWeight: FontWeight.w500),

//                               /*defining default style is optional */
//                               children: <TextSpan>[
//                                 TextSpan(
//                                   text: ' (2)',
//                                   style: TextStyle(
//                                       fontFamily: 'Campton',
//                                       color: Colors.black,
//                                       fontSize: 15.sp,
//                                       fontWeight: FontWeight.w700),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                   SvgPicture.asset("assets/icons/forword.svg"),
//                 ],
//               ),
//             ),
//           ),
//           GestureDetector(
//             onTap: () {
//               Navigator.push(
//                 context,
//                 SlidePageRoute(
//                   page: MdFoodView(
//                       // packageId:MdShopView
//                       //     widget.packageId,
//                       ),
//                   direction:
//                       SlideDirection.right, // Specify the slide direction here
//                   delay: Duration(milliseconds: 5000),
//                 ),
//               );
//             },
//             child: Container(
//               margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 20.w),
//               padding: EdgeInsets.only(
//                   left: 20.w, right: 30.w, top: 17.w, bottom: 18.w),
//               decoration: BoxDecoration(
//                   color: Color(0xffFBFBFB),
//                   borderRadius: BorderRadius.circular(10),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.10),
//                       // offset: Offset(2, 2),
//                       blurRadius: 20,
//                     ),
//                   ]),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Row(
//                     children: [
//                       SvgPicture.asset(
//                         "assets/icons/fluent_food-24-filled.svg",
//                         width: 35.w,
//                         height: 40.w,
//                       ),
//                       // Image.asset(
//                       //   "assets/images/black_favourt.png",
//                       //   width: 35.w,
//                       //   height: 27.w,
//                       // ),
//                       SizedBox(
//                         width: 10.h,
//                       ),
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           RichText(
//                             text: TextSpan(
//                               text: 'MD',
//                               style: TextStyle(
//                                   fontFamily: 'Campton',
//                                   color: Colors.black,
//                                   fontSize: 16.sp,
//                                   fontWeight: FontWeight.w600),

//                               /*defining default style is optional */
//                               children: <TextSpan>[
//                                 TextSpan(
//                                   text: 'food',
//                                   style: TextStyle(
//                                       fontFamily: 'Campton',
//                                       color: Colors.black,
//                                       fontSize: 19.sp,
//                                       fontWeight: FontWeight.w400),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           RichText(
//                             text: TextSpan(
//                               text: 'Purchase',
//                               style: TextStyle(
//                                   fontFamily: 'Campton',
//                                   color: Colors.black,
//                                   fontSize: 15.sp,
//                                   fontWeight: FontWeight.w500),

//                               /*defining default style is optional */
//                               children: <TextSpan>[
//                                 TextSpan(
//                                   text: ' (2)',
//                                   style: TextStyle(
//                                       fontFamily: 'Campton',
//                                       color: Colors.black,
//                                       fontSize: 15.sp,
//                                       fontWeight: FontWeight.w700),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                   SvgPicture.asset("assets/icons/forword.svg"),
//                 ],
//               ),
//             ),
//           ),
//           GestureDetector(
//             onTap: () {
//               Navigator.push(
//                 context,
//                 SlidePageRoute(
//                   page: MdFoodView(
//                       // packageId:MdShopView
//                       //     widget.packageId,
//                       ),
//                   direction:
//                       SlideDirection.right, // Specify the slide direction here
//                   delay: Duration(milliseconds: 5000),
//                 ),
//               );
//             },
//             child: Container(
//               margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 20.w),
//               padding: EdgeInsets.only(
//                   left: 20.w, right: 30.w, top: 17.w, bottom: 18.w),
//               decoration: BoxDecoration(
//                   color: Color(0xffFBFBFB),
//                   borderRadius: BorderRadius.circular(10),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.10),
//                       // offset: Offset(2, 2),
//                       blurRadius: 20,
//                     ),
//                   ]),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Row(
//                     children: [
//                       SvgPicture.asset(
//                         "assets/icons/medical-icon_i-care-staff-area.svg",
//                         width: 35.w,
//                         height: 40.w,
//                       ),

//                       // Image.asset(
//                       //   "assets/images/medical-icon_i-care-staff-area.png",
//                       // width: 35.w,
//                       // height: 27.w,
//                       // ),
//                       SizedBox(
//                         width: 10.h,
//                       ),
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           RichText(
//                             text: TextSpan(
//                               text: 'MD',
//                               style: TextStyle(
//                                   fontFamily: 'Campton',
//                                   color: Colors.black,
//                                   fontSize: 16.sp,
//                                   fontWeight: FontWeight.w600),

//                               /*defining default style is optional */
//                               children: <TextSpan>[
//                                 TextSpan(
//                                   text: 'home',
//                                   style: TextStyle(
//                                       fontFamily: 'Campton',
//                                       color: Colors.black,
//                                       fontSize: 19.sp,
//                                       fontWeight: FontWeight.w400),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           RichText(
//                             text: TextSpan(
//                               text: 'Purchase',
//                               style: TextStyle(
//                                   fontFamily: 'Campton',
//                                   color: Colors.black,
//                                   fontSize: 15.sp,
//                                   fontWeight: FontWeight.w500),

//                               /*defining default style is optional */
//                               children: <TextSpan>[
//                                 TextSpan(
//                                   text: ' (2)',
//                                   style: TextStyle(
//                                       fontFamily: 'Campton',
//                                       color: Colors.black,
//                                       fontSize: 15.sp,
//                                       fontWeight: FontWeight.w700),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                   SvgPicture.asset("assets/icons/forword.svg"),
//                 ],
//               ),
//             ),
//           ),
//         ])));
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:md_health/Screens/bottom_navigation/controller/bottom_controller.dart';
import 'package:md_health/Screens/favourt/view/health_favt_pa_list_details.dart';
import 'package:md_health/Screens/main/controller/main_screen_controller.dart';
import 'package:md_health/Screens/order/controller/order_count_controller.dart';
import 'package:md_health/Screens/order_details/view/md_food_view.dart';
import 'package:md_health/Screens/order_details/view/md_home_view.dart';
import 'package:md_health/Screens/order_details/view/md_shop_view.dart';
import 'package:md_health/Screens/packages/view/packages_view.dart';
import 'package:md_health/test_widget.dart';
import 'package:md_health/widget/custom_appbar.dart';
import 'package:md_health/widget/drawer.dart';
import 'package:provider/provider.dart';

class PurchesItemView extends StatefulWidget {
  const PurchesItemView({super.key});

  @override
  State<PurchesItemView> createState() => _PurchesItemViewState();
}

class _PurchesItemViewState extends State<PurchesItemView> {
  void initState() {
    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
      // log(widget.packageId ?? '');
      context.read<DietOrderCountController>().initState(
            context,
          );
    });
  }

  @override
  Widget build(BuildContext context) {
    // final read = context.read<NewMainScreenController>();
    // final watch = context.watch<NewMainScreenController>();
    final read = context.read<DietOrderCountController>();
    final watch = context.watch<DietOrderCountController>();
    return Container(
      height: ScreenUtil().screenHeight,
      color: Colors.white,
      child: SingleChildScrollView(
        child: Column(
          children: [
            // Container(
            //   // margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 38.w),
            //   child: ListView.builder(
            //     shrinkWrap: true,
            //     physics: NeverScrollableScrollPhysics(),
            //     itemCount: 2,
            //     itemBuilder: (context, index) {
            //       return GestureDetector(
            //         onTap: () {
            //           Navigator.push(
            //             context,
            //             MaterialPageRoute(builder: (context) => MdShopView()),
            //           );
            //           //
            //         },
            //         child: Container(
            //           padding: EdgeInsets.only(
            //             left: 18.w,
            //             right: 18.w,
            //           ),
            //           child: Column(
            //             children: [
            //               // SizedBox(
            //               //   height: 100,
            //               // ),
            //               Container(
            //                 child: Container(
            //                   padding: EdgeInsets.only(
            //                       left: 20.w,
            //                       right: 30.w,
            //                       top: 10.w,
            //                       bottom: 10.w),
            //                   decoration: BoxDecoration(
            //                       color: Colors.white,
            //                       borderRadius: BorderRadius.circular(10),
            //                       boxShadow: [
            //                         BoxShadow(
            //                           color: Colors.black.withOpacity(0.10),
            //                           // offset: Offset(2, 2),
            //                           blurRadius: 20,
            //                         ),
            //                       ]),
            //                   child: Row(
            //                     mainAxisAlignment:
            //                         MainAxisAlignment.spaceBetween,
            //                     children: [
            //                       Row(
            //                         children: [
            //                           SvgPicture.asset("assets/icons/food.svg"),
            //                           Column(
            //                             children: [
            //                               RichText(
            //                                 text: TextSpan(
            //                                   text: 'MD',
            //                                   style: TextStyle(
            //                                       fontFamily: 'Campton',
            //                                       color: Colors.black,
            //                                       fontSize: 16.sp,
            //                                       fontWeight: FontWeight.w600),

            //                                   /*defining default style is optional */
            //                                   children: <TextSpan>[
            //                                     TextSpan(
            //                                       text: 'shop',
            //                                       style: TextStyle(
            //                                           fontFamily: 'Campton',
            //                                           color: Colors.black,
            //                                           fontSize: 19.sp,
            //                                           fontWeight:
            //                                               FontWeight.w400),
            //                                     ),
            //                                   ],
            //                                 ),
            //                               ),
            //                               RichText(
            //                                 text: TextSpan(
            //                                   text: 'Orders',
            //                                   style: TextStyle(
            //                                       fontFamily: 'Campton',
            //                                       color: Colors.black,
            //                                       fontSize: 15.sp,
            //                                       fontWeight: FontWeight.w500),

            //                                   /*defining default style is optional */
            //                                   children: <TextSpan>[
            //                                     TextSpan(
            //                                       text: '(2)',
            //                                       style: TextStyle(
            //                                           fontFamily: 'Campton',
            //                                           color: Colors.black,
            //                                           fontSize: 15.sp,
            //                                           fontWeight:
            //                                               FontWeight.w700),
            //                                     ),
            //                                   ],
            //                                 ),
            //                               ),
            //                             ],
            //                           ),
            //                         ],
            //                       ),
            //                       SvgPicture.asset("assets/icons/forword.svg"),
            //                     ],
            //                   ),
            //                 ),
            //               ),
            //               SizedBox(
            //                 height: 15.h,
            //               ),
            //             ],
            //           ),
            //         ),
            //       );
            //     },
            //   ),
            // ),
            // GestureDetector(
            //   onTap: () {
            //     Navigator.push(
            //       context,
            //       SlidePageRoute(
            //         page: PackageSView(
            //             // packageId:MdShopView
            //             //     widget.packageId,
            //             ),
            //         direction: SlideDirection
            //             .right, // Specify the slide direction here
            //         delay: Duration(milliseconds: 5000),
            //       ),
            //     );
            //   },
            //   child: Container(
            //     margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 20.w),
            //     padding: EdgeInsets.only(
            //         left: 20.w, right: 30.w, top: 17.w, bottom: 18.w),
            //     decoration: BoxDecoration(
            //         color: Color(0xffFBFBFB),
            //         borderRadius: BorderRadius.circular(10),
            //         boxShadow: [
            //           BoxShadow(
            //             color: Colors.black.withOpacity(0.10),
            //             // offset: Offset(2, 2),
            //             blurRadius: 20,
            //           ),
            //         ]),
            //     child: Row(
            //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //       children: [
            //         Row(
            //           children: [
            //             Image.asset(
            //               "assets/images/black_favourt.png",
            //               width: 35.w,
            //               height: 27.w,
            //             ),
            //             SizedBox(
            //               width: 10.h,
            //             ),
            //             Column(
            //               crossAxisAlignment: CrossAxisAlignment.start,
            //               children: [
            //                 RichText(
            //                   text: TextSpan(
            //                     text: 'MD',
            //                     style: TextStyle(
            //                         fontFamily: 'Campton',
            //                         color: Colors.black,
            //                         fontSize: 16.sp,
            //                         fontWeight: FontWeight.w600),

            //                     /*defining default style is optional */
            //                     children: <TextSpan>[
            //                       TextSpan(
            //                         text: 'health',
            //                         style: TextStyle(
            //                             fontFamily: 'Campton',
            //                             color: Colors.black,
            //                             fontSize: 19.sp,
            //                             fontWeight: FontWeight.w400),
            //                       ),
            //                     ],
            //                   ),
            //                 ),
            //                 RichText(
            //                   text: TextSpan(
            //                     text: 'Purchase',
            //                     style: TextStyle(
            //                         fontFamily: 'Campton',
            //                         color: Colors.black,
            //                         fontSize: 15.sp,
            //                         fontWeight: FontWeight.w500),

            //                     /*defining default style is optional */
            //                     children: <TextSpan>[
            //                       TextSpan(
            //                         text: ' (2)',
            //                         style: TextStyle(
            //                             fontFamily: 'Campton',
            //                             color: Colors.black,
            //                             fontSize: 15.sp,
            //                             fontWeight: FontWeight.w700),
            //                       ),
            //                     ],
            //                   ),
            //                 ),
            //               ],
            //             ),
            //           ],
            //         ),
            //         SvgPicture.asset("assets/icons/forword.svg"),
            //       ],
            //     ),
            //   ),
            // ),
            // GestureDetector(
            //   onTap: () {
            //     Navigator.push(
            //       context,
            //       SlidePageRoute(
            //         page: MdShopView(
            //             // packageId:MdShopView
            //             //     widget.packageId,
            //             ),
            //         direction: SlideDirection
            //             .right, // Specify the slide direction here
            //         delay: Duration(milliseconds: 5000),
            //       ),
            //     );
            //   },
            //   child: Container(
            //     margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 20.w),
            //     padding: EdgeInsets.only(
            //         left: 20.w, right: 30.w, top: 17.w, bottom: 18.w),
            //     decoration: BoxDecoration(
            //         color: Color(0xffFBFBFB),
            //         borderRadius: BorderRadius.circular(10),
            //         boxShadow: [
            //           BoxShadow(
            //             color: Colors.black.withOpacity(0.10),
            //             // offset: Offset(2, 2),
            //             blurRadius: 20,
            //           ),
            //         ]),
            //     child: Row(
            //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //       children: [
            //         Row(
            //           children: [
            //             SvgPicture.asset(
            //               "assets/icons/fluent-mdl2_shop.svg",
            //               width: 35.w,
            //               height: 40.w,
            //             ),
            //             // Image.asset(
            //             //   "assets/images/black_favourt.png",
            //             //   width: 35.w,
            //             //   height: 27.w,
            //             // ),
            //             SizedBox(
            //               width: 10.h,
            //             ),
            //             Column(
            //               crossAxisAlignment: CrossAxisAlignment.start,
            //               children: [
            //                 RichText(
            //                   text: TextSpan(
            //                     text: 'MD',
            //                     style: TextStyle(
            //                         fontFamily: 'Campton',
            //                         color: Colors.black,
            //                         fontSize: 16.sp,
            //                         fontWeight: FontWeight.w600),

            //                     /*defining default style is optional */
            //                     children: <TextSpan>[
            //                       TextSpan(
            //                         text: 'shop',
            //                         style: TextStyle(
            //                             fontFamily: 'Campton',
            //                             color: Colors.black,
            //                             fontSize: 19.sp,
            //                             fontWeight: FontWeight.w400),
            //                       ),
            //                     ],
            //                   ),
            //                 ),
            //                 RichText(
            //                   text: TextSpan(
            //                     text: 'Purchase',
            //                     style: TextStyle(
            //                         fontFamily: 'Campton',
            //                         color: Colors.black,
            //                         fontSize: 15.sp,
            //                         fontWeight: FontWeight.w500),

            //                     /*defining default style is optional */
            //                     children: <TextSpan>[
            //                       TextSpan(
            //                         text: ' (2)',
            //                         style: TextStyle(
            //                             fontFamily: 'Campton',
            //                             color: Colors.black,
            //                             fontSize: 15.sp,
            //                             fontWeight: FontWeight.w700),
            //                       ),
            //                     ],
            //                   ),
            //                 ),
            //               ],
            //             ),
            //           ],
            //         ),
            //         SvgPicture.asset("assets/icons/forword.svg"),
            //       ],
            //     ),
            //   ),
            // ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  SlidePageRoute(
                    page: MdFoodView(
                        // packageId:MdShopView
                        //     widget.packageId,
                        ),
                    direction: SlideDirection
                        .right, // Specify the slide direction here
                    delay: Duration(milliseconds: 5000),
                  ),
                );
              },
              child: Container(
                margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 20.w),
                padding: EdgeInsets.only(
                    left: 20.w, right: 30.w, top: 17.w, bottom: 18.w),
                decoration: BoxDecoration(
                    color: Color(0xffFBFBFB),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.10),
                        // offset: Offset(2, 2),
                        blurRadius: 20,
                      ),
                    ]),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        SvgPicture.asset(
                          "assets/icons/fluent_food-24-filled.svg",
                          width: 35.w,
                          height: 40.w,
                        ),
                        SizedBox(
                          width: 10.h,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RichText(
                              text: TextSpan(
                                text: 'MD',
                                style: TextStyle(
                                    fontFamily: 'Campton',
                                    color: Colors.black,
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600),

                                /*defining default style is optional */
                                children: <TextSpan>[
                                  TextSpan(
                                    text: 'food',
                                    style: TextStyle(
                                        fontFamily: 'Campton',
                                        color: Colors.black,
                                        fontSize: 19.sp,
                                        fontWeight: FontWeight.w400),
                                  ),
                                ],
                              ),
                            ),
                            RichText(
                              text: TextSpan(
                                text: 'Purchase',
                                style: TextStyle(
                                    fontFamily: 'Campton',
                                    color: Colors.black,
                                    fontSize: 15.sp,
                                    fontWeight: FontWeight.w500),

                                /*defining default style is optional */
                                children: <TextSpan>[
                                  TextSpan(
                                    text: ' (${watch.orderCount ?? 0})',
                                    style: TextStyle(
                                        fontFamily: 'Campton',
                                        color: Colors.black,
                                        fontSize: 15.sp,
                                        fontWeight: FontWeight.w700),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SvgPicture.asset("assets/icons/forword.svg"),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  SlidePageRoute(
                    page: OrderMdShopView(
                        // packageId:MdShopView
                        //     widget.packageId,
                        ),
                    direction: SlideDirection
                        .right, // Specify the slide direction here
                    delay: Duration(milliseconds: 5000),
                  ),
                );
              },
              child: Container(
                margin: EdgeInsets.only(left: 18.w, right: 18.w, top: 20.w),
                padding: EdgeInsets.only(
                    left: 20.w, right: 30.w, top: 17.w, bottom: 18.w),
                decoration: BoxDecoration(
                    color: Color(0xffFBFBFB),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.10),
                        // offset: Offset(2, 2),
                        blurRadius: 20,
                      ),
                    ]),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        SvgPicture.asset(
                          "assets/icons/fluent-mdl2_shop (1).svg",
                          width: 35.w,
                          height: 40.w,
                        ),

                        // Image.asset(
                        //   "assets/images/medical-icon_i-care-staff-area.png",
                        // width: 35.w,
                        // height: 27.w,
                        // ),
                        SizedBox(
                          width: 10.h,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RichText(
                              text: TextSpan(
                                text: 'MD',
                                style: TextStyle(
                                    fontFamily: 'Campton',
                                    color: Colors.black,
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600),

                                /*defining default style is optional */
                                children: <TextSpan>[
                                  TextSpan(
                                    text: ' shop',
                                    style: TextStyle(
                                        fontFamily: 'Campton',
                                        color: Colors.black,
                                        fontSize: 19.sp,
                                        fontWeight: FontWeight.w400),
                                  ),
                                ],
                              ),
                            ),
                            RichText(
                              text: TextSpan(
                                text: 'Purchase',
                                style: TextStyle(
                                    fontFamily: 'Campton',
                                    color: Colors.black,
                                    fontSize: 15.sp,
                                    fontWeight: FontWeight.w500),

                                /*defining default style is optional */
                                children: <TextSpan>[
                                  TextSpan(
                                    text: ' (${watch.shopOrderCount ?? 0})',
                                    style: TextStyle(
                                        fontFamily: 'Campton',
                                        color: Colors.black,
                                        fontSize: 15.sp,
                                        fontWeight: FontWeight.w700),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SvgPicture.asset("assets/icons/forword.svg"),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
