import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:md_health/Screens/hotel/view/hotel_review.dart';
import 'package:md_health/Screens/packages/controller/packages_view_controller.dart';
import 'package:md_health/Screens/packages/view/review_view.dart';
import 'package:md_health/constants/styles/colors.dart';
import 'package:md_health/widget/buttons.dart';
import 'package:md_health/widget/drop_down.dart';
import 'package:md_health/widget/network_image.dart';
import 'package:md_health/widget/rating.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CompletedPackageView extends StatefulWidget {
  final String? index;
  const CompletedPackageView({super.key, this.index});

  @override
  State<CompletedPackageView> createState() => _CompletedPackageViewState();
}

class _CompletedPackageViewState extends State<CompletedPackageView> {
  @override
  void initState() {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      context
          .read<PackageViewController>()
          .initState(context, widget.index, "", "");
    });
  }

  @override
  Widget build(BuildContext context) {
    final read = context.read<PackageViewController>();
    final watch = context.watch<PackageViewController>();

    return Column(
      children: [
        Padding(
          padding: EdgeInsets.only(
            right: 19.0.w,
            left: 19.0.w,
            // top: 13.h,
          ),
          child: SizedBox(
            height: 36.h,
            child: TextField(
              onChanged: (value) {
                read.comeSearchList(context);
              },
              // autofocus: widget.isSearchFocus ?? true,
              controller: watch.searchCompletedController,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(width: 1, color: black),
                    borderRadius: BorderRadius.circular(8.w)),
                focusedBorder: OutlineInputBorder(
                    borderSide:
                        const BorderSide(width: 1, color: kDefaultActiveColor),
                    borderRadius: BorderRadius.circular(8.w)),
                hintText: 'Search Packages.......',
                hintStyle: GoogleFonts.dmSans(
                    textStyle: TextStyle(
                        color: black,
                        // letterSpacing: .5,
                        fontSize: 11,
                        fontWeight: FontWeight.w400)),
                prefixIcon: IconButton(
                  icon: SvgPicture.asset(
                    'assets/icons/search.svg',
                    // alignment: Alignment.topRight,
                  ),
                  //  SvgPicture.asset(
                  //   'assets/icons/search.svg',
                  //   width: 15.w,
                  //   height: 15.h,
                  // ),
                  onPressed: () {
                    // Perform the search here
                  },
                ),
              ),
            ),
          ),
        ),
        // Padding(
        //   padding: EdgeInsets.only(
        //     right: 19.0.w,
        //     left: 19.0.w,
        //     // top: 13.h,
        //   ),
        //   child: SizedBox(
        //     height: 36.h,
        //     child: TextField(
        //       onChanged: (value) {
        //         read.completedSearchList(context);
        //       },
        //       // autofocus: widget.isSearchFocus ?? true,
        //       controller: watch.searchCompletedController,
        //       decoration: InputDecoration(
        //         enabledBorder: OutlineInputBorder(
        //             borderSide: const BorderSide(width: 1, color: black),
        //             borderRadius: BorderRadius.circular(8.w)),
        //         focusedBorder: OutlineInputBorder(
        //             borderSide:
        //                 const BorderSide(width: 1, color: kDefaultActiveColor),
        //             borderRadius: BorderRadius.circular(8.w)),
        //         hintText: 'Search Packages.......',
        //         hintStyle: GoogleFonts.dmSans(
        //             textStyle: TextStyle(
        //                 color: black,
        //                 // letterSpacing: .5,
        //                 fontSize: 11.sp,
        //                 fontWeight: FontWeight.w400)),
        //         prefixIcon: IconButton(
        //           icon: SvgPicture.asset(
        //             'assets/icons/search.svg',
        //             // alignment: Alignment.topRight,
        //           ),
        //           //  SvgPicture.asset(
        //           //   'assets/icons/search.svg',
        //           //   width: 15.w,
        //           //   height: 15.h,
        //           // ),
        //           onPressed: () {
        //             // Perform the search here
        //           },
        //         ),
        //       ),
        //     ),
        //   ),
        // ),
        Container(
            // margin: EdgeInsets.only(left: 18.w, right: 18.w),
            child: watch.customerPurchasePackageCompletedList?.isNotEmpty ==
                    true
                ? ListView.builder(
                    padding:
                        EdgeInsets.only(left: 10.w, right: 10.w, top: 10.w),
                    itemCount:
                        watch.customerPurchasePackageCompletedList?.length ?? 0,
                    //  watch.customerPurchasePackageActiveList??,
                    physics: const BouncingScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (BuildContext, index) {
                      final element =
                          watch.customerPurchasePackageCompletedList?[index];
                      return GestureDetector(
                        onTap: () {},
                        child: Container(
                          padding: EdgeInsets.only(bottom: 17.w),
                          decoration: BoxDecoration(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              // border: Border.all(color: const Color(0xffEFEFEF)),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    spreadRadius: 1,
                                    blurRadius: 10,
                                    blurStyle: BlurStyle.outer)
                              ]),
                          child: Container(
                            padding: EdgeInsets.only(
                                left: 16.w, right: 18.w, top: 5.w),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    element?.companyLogoImagePath == ""
                                        ? SizedBox(
                                            width: 50.w,
                                            height: 50.h,
                                            child: Image.asset(
                                              "assets/images/image_not_found.png",
                                              fit: BoxFit.cover,
                                            ),
                                          )
                                        : SizedBox(
                                            width: 50.w,
                                            height: 50.h,
                                            child: AppNetworkImages(
                                              imageUrl:
                                                  "${element?.companyLogoImagePath}",
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                    SizedBox(
                                      width: 10.w,
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          "${element?.companyName}",
                                          style: TextStyle(
                                              fontFamily: 'Campton',
                                              color: black,
                                              // letterSpacing: 5.5,
                                              fontSize: 17.sp,
                                              fontWeight: FontWeight.w700),
                                        ),
                                        Container(
                                          width: 200.w,
                                          child: Text(
                                            "${element?.packageName}",
                                            style: TextStyle(
                                                fontFamily: 'Campton',
                                                color: black,
                                                // letterSpacing: 5.5,
                                                fontSize: 14.sp,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                                SizedBox(
                                  height: 10.h,
                                ),
                                Row(
                                  // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                          'assets/icons/location.svg',
                                          // alignment: Alignment.topRight,
                                        ),
                                        Container(
                                          width: 110.w,
                                          child: Text(
                                            "${element?.cityName}",
                                            style: TextStyle(
                                                fontStyle: FontStyle.italic,
                                                fontFamily: 'Campton',
                                                color: Color(0xff212121),
                                                fontSize: 13,
                                                fontWeight: FontWeight.w400),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                          'assets/icons/time.svg',
                                          alignment: Alignment.topRight,
                                        ),
                                        Text(
                                          "Treatment Periods ${element?.treatmentPeriodInDays}",
                                          style: TextStyle(
                                              fontFamily: 'Campton',
                                              color: Color(0xff212121),
                                              fontSize: 13,
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w400),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 10.h,
                                ),
                                SizedBox(
                                  height: 14.h,
                                ),
                                PrimaryButton(
                                  borderRadius: 30,
                                  color: Color(0xffF3771D),
                                  onTap: () {
                                    print(
                                      element?.id.toString(),
                                    );
                                    print(
                                      element?.packageId.toString(),
                                    );
                                    // return;
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              ReviewForPackageView(
                                                packageId: element?.packageId
                                                    .toString(),
                                                purchesId:
                                                    element?.id.toString(),
                                              )),
                                    );
                                  },
                                  child: Text(
                                    "Write Review",
                                    style: TextStyle(
                                        fontFamily: 'Campton',
                                        color: Colors.white,
                                        // letterSpacing: .5,
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                                SizedBox(
                                  height: 20.h,
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    })
                : Center(
                    child: Column(
                      children: [
                        SizedBox(
                          height: 120.h,
                        ),
                        SvgPicture.asset(
                          "assets/icons/kiran_no_data_found.svg",
                          // width: 10,
                        ),
                      ],
                    ),
                  )),
      ],
    );
  }
}
