class WirteReviewRequestModel {
  String? packageId;
  String? purchaseId;
  String? cleanliness;
  String? comfort;
  String? foodQuality;
  String? behaviorValue;
  String? accomodation;
  String? transportation;
  String? tour;
  String? notes;

  WirteReviewRequestModel({
    this.packageId,
    this.purchaseId,
    this.cleanliness,
    this.comfort,
    this.foodQuality,
    this.behaviorValue,
    this.accomodation,
    this.transportation,
    this.tour,
    this.notes,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data["package_id"] = packageId;
    data["purchase_id"] = purchaseId;
    data["treatment"] = cleanliness;
    data["comfort"] = comfort;
    data["recommended_service"] = foodQuality;
    data["behaviour_reviews"] = behaviorValue;
    data["recommended_hotel"] = accomodation;
    data["recommended_vehicle"] = transportation;
    data["recommended_tour"] = tour;
    data["extra_notes"] = notes;
    return data;
  }
}

////////////////////////////////////////
class WirteReviewResponseModel {
  int? status;
  String? message;

  WirteReviewResponseModel({
    required this.status,
    required this.message,
  });
  WirteReviewResponseModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
  }
}
