import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:md_health/Screens/packages/model/active_package_model.dart';
import 'package:md_health/Screens/packages/model/active_review_model.dart';
import 'package:md_health/Screens/packages/model/cancelled_package_model.dart';
import 'package:md_health/Screens/packages/model/completed_package_model.dart';
import 'package:md_health/Screens/packages/model/package_detail_view_model.dart';
import 'package:md_health/Screens/packages/model/review_model.dart';
import 'package:md_health/Screens/packages/repository/active_package_repo.dart';
import 'package:md_health/Screens/packages/repository/cancelled_package_repo.dart';
import 'package:md_health/Screens/packages/repository/complete_package_repo.dart';
import 'package:md_health/Screens/packages/repository/package_detail_view_repo.dart';
import 'package:md_health/Screens/packages/repository/review_repo.dart';
import 'package:md_health/Screens/packages/repository/three_review_repo.dart';
import 'package:md_health/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WriteReviewController extends ChangeNotifier {
  WriteReviewRepo writeReviewRepo = WriteReviewRepo();
  ThreeReviewRepo threeReviewRepo = ThreeReviewRepo();
  TextEditingController reviewController = TextEditingController();

  String packageId = '';
  String purcheseId = '';
  bool isLoading = true;
  double? cleanless;
  double? ratingValues;
  double? transportationValueratingValue;
  double? behaviorValueratingValue;
  double? newStartOne;
  double? newStartTwo;
  double? newStartThree;
  double? comfort;
  double? food;

  Future<void> initState(context, pId, puId
      // valueTreatment, valueTransportation,
      //     valueBehaviorValue, valueacommmodation
      ) async {
    await threeReview(context, puId);
    notifyListeners();
  }

/////////////////////////////

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  void onRatingSelectsCleanless(value) {
    cleanless = value;
    notifyListeners();
  }

  void onRatingSelectsComfort(value) {
    comfort = value;
    notifyListeners();
  }

  void onRatingSelectsFood(value) {
    food = value;
    notifyListeners();
  }

  void onRatingSelectsBehavior(value) {
    behaviorValueratingValue = value;
    notifyListeners();
  }
  /////////////////////////

  void onRatingNewOne(value) {
    newStartOne = value;
    notifyListeners();
  }

  void onRatingNewTWO(value) {
    newStartTwo = value;
    notifyListeners();
  }

  void onRatingNewtHREE(value) {
    newStartThree = value;
    notifyListeners();
  }

  WirteReviewRequestModel get wirteReviewRequestModel =>
      WirteReviewRequestModel(
          purchaseId: purcheseId,
          packageId: purcheseId,
          notes: reviewController.text,
          behaviorValue: behaviorValueratingValue.toString(),
          foodQuality: food.toString(),
          comfort: comfort.toString(),
          cleanliness: cleanless.toString(),
          tour: newStartThree.toString(),
          transportation: newStartTwo.toString(),
          accomodation: newStartOne.toString()
          // treatmentValue: treatmentValueratingValue.toString(),
          // notes: reviewController.text,
          // transportationValue: transportationValueratingValue.toString(),
          // behaviorValue: behaviorValueratingValue.toString(),
          // acommmodationValue: acommmodationValueratingValue.toString(),
          // packageId: packageId
          );
  Future<void> writeReview(context, pId, puId
      // valueTreatment, valueTransportation,
      //     valueBehaviorValue, valueacommmodation
      ) async {
    showLoader(true);
    packageId = pId;
    packageId = puId;
    // treatmentValueratingValue = valueTreatment;
    // transportationValueratingValue = valueTransportation;
    // behaviorValueratingValue = valueBehaviorValue;
    // acommmodationValueratingValue = valueacommmodation;
    SharedPreferences pref = await SharedPreferences.getInstance();
    writeReviewRepo
        .writereview(wirteReviewRequestModel, pref.getString("successToken"))
        .then((response) async {
      // log(response.body);
      debugPrint('/////////////');
      final result =
          WirteReviewResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        // customerReviewsData = result.customerReviewsData;
        // reviewController.text = customerReviewsData?.extraNotes ?? "";

        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  ReviewsScreenData? reviewsScreenDatas;

  ///////////////
  ActiveReviewRequestMOdel get activeReviewRequestMOdel =>
      ActiveReviewRequestMOdel(
        purchaseId: purcheseId.toString(),
      );
  Future<void> threeReview(context, puId) async {
    showLoader(true);
    purcheseId = puId;

    SharedPreferences pref = await SharedPreferences.getInstance();
    threeReviewRepo
        .threeReview(activeReviewRequestMOdel, pref.getString("successToken"))
        .then((response) async {
      debugPrint('/////////////');
      final result =
          ActiveReviewResponseMOdel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        reviewsScreenDatas = result.reviewsScreenDatas;
        showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
}
