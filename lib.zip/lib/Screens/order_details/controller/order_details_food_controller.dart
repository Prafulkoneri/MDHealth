import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:md_health/Screens/auth/repository/country_list_repository.dart';
import 'package:md_health/Screens/order_details/model/country_list_model.dart';
import 'package:md_health/Screens/order_details/model/country_search_list_model.dart';
import 'package:md_health/Screens/order_details/model/order_details_food_model.dart';
import 'package:md_health/Screens/order_details/model/shop_order_details_model.dart';
import 'package:md_health/Screens/order_details/repo/food_order_details_repo.dart';
import 'package:md_health/Screens/order_details/repo/order_list_repo.dart';
import 'package:md_health/Screens/order_details/repo/order_search_package_repo.dart';
import 'package:md_health/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OrderListFoodViewController extends ChangeNotifier {
  FoodOrderDetailsRepo foodOrderDetailsRepo = FoodOrderDetailsRepo();
  CountrySearchRepo countrySearchRepo = CountrySearchRepo();
  String foodOrderId = '';

  bool isLoading = true;

  Future<void> initState(context, fodId) async {
    await FoodOrderDetailsView(context, fodId);
    notifyListeners();
  }

/////////////////////////////

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  OrderFoodDetails? orderFoodDetails;

  OrderListDetailsRequestModel get orderListDetailsRequestModel =>
      OrderListDetailsRequestModel(
        foodOrderId: foodOrderId,
      );
  Future<void> FoodOrderDetailsView(context, fodId) async {
    foodOrderId = fodId.toString();

    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    foodOrderDetailsRepo
        .foodOrderDetails(
            orderListDetailsRequestModel, pref.getString("successToken"))
        .then((response) async {
      final result = OrderListReponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        orderFoodDetails = result.orderFoodDetails;
        log(response.body);
        // Utils.showPrimarySnackbar(context, result.message,
        //     type: SnackType.success);
        showLoader(false);
        notifyListeners();
      }
      notifyListeners();
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
  ////////////////////////////////
}
