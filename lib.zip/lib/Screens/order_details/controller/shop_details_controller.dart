import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:md_health/Screens/auth/model/city_list_model.dart';
import 'package:md_health/Screens/auth/repository/city_list_repository.dart';
import 'package:md_health/Screens/auth/repository/country_list_repository.dart';
import 'package:md_health/Screens/order/view/order_view.dart';
import 'package:md_health/Screens/order_details/model/country_list_model.dart';
import 'package:md_health/Screens/order_details/model/country_search_list_model.dart';
import 'package:md_health/Screens/order_details/model/order_cancelled_shop_model.dart';
import 'package:md_health/Screens/order_details/model/order_details_food_model.dart';
import 'package:md_health/Screens/order_details/model/shop_order_change_address_model.dart';
import 'package:md_health/Screens/order_details/model/shop_order_details_model.dart';
import 'package:md_health/Screens/order_details/repo/calShopOrder_repo.dart';
import 'package:md_health/Screens/order_details/repo/chnage_address_repo.dart';
import 'package:md_health/Screens/order_details/repo/food_order_details_repo.dart';
import 'package:md_health/Screens/order_details/repo/order_list_repo.dart';
import 'package:md_health/Screens/order_details/repo/order_search_package_repo.dart';
import 'package:md_health/Screens/order_details/repo/shop_order_details_repo.dart';
import 'package:md_health/Screens/order_details/view/md_food_view.dart';
import 'package:md_health/Screens/order_details/view/md_shop_view.dart';
import 'package:md_health/test_widget.dart';
import 'package:md_health/utils/utils.dart';
import 'package:md_health/widget/loading_overlay.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ShopListDetailsController extends ChangeNotifier {
  ShopOrderDetailsRepo shopOrderDetailsRepo = ShopOrderDetailsRepo();
  CancelledShopOrdeRepo cancelledShopOrdeRepo = CancelledShopOrdeRepo();
  CityListRepository cityListRepo = CityListRepository();
  ChangeAddressRepo changeAddressRepo = ChangeAddressRepo();

  String shopOrderId = '';
  String countryId = '';
  List<SdhopProductDetails>? shopProductDetails;
  String? deliveryCharge;
  int? productAmountPaid;
  int? totalAmountPaid;
  int? productCount;
  String? paymentStatus;
  String? orderId;
  String? paymentMode;
  String? orderStatus;
  String? paymentDate;
  String? cargoCompanyName;
  String? cargoTrackingNumber;
  String? city;
  String? country;
  String? address;
  bool isLoading = true;

  Future<void> initState(context, shdId) async {
    print("orderId");
    print(orderId);
    print("orderId");
    await ShopOrderDetailsView(context, shdId);
    getCountry(context);
    notifyListeners();
  }

  String selectedCountry = 'Choose Country'; // Change String? to String
  String selectedCity = 'Choose City'; // Change String? to String
  void selectCountry(String country) {
    selectedCountry = country;
    notifyListeners();
  }

  void selectCity(String city) {
    selectedCity = city;
    notifyListeners();
  }

/////////////////////////////

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  OrderFoodDetails? orderFoodDetails;

  DetailsShopOrderListRequestModel get detailsShopOrderListRequestModel =>
      DetailsShopOrderListRequestModel(
        shopOrderId: shopOrderId,
      );
  Future<void> ShopOrderDetailsView(context, shdId) async {
    shopOrderId = shdId.toString();

    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    shopOrderDetailsRepo
        .shopOrderDetails(
            detailsShopOrderListRequestModel, pref.getString("successToken"))
        .then((response) async {
      final result =
          ShopOrderListResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        shopProductDetails = result.shopProductDetails;
        deliveryCharge = result.deliveryCharge.toString();
        productAmountPaid = result.productAmountPaid;
        totalAmountPaid = result.totalAmountPaid;
        orderId = result.orderId;
        productCount = result.productCount;
        paymentStatus = result.paymentStatus;
        paymentMode = result.paymentMode;
        orderStatus = result.orderStatus;
        paymentDate = result.paymentDate;
        cargoCompanyName = result.cargoCompanyName;
        cargoTrackingNumber = result.cargoTrackingNumber;
        city = result.cityName;
        country = result.countryName;
        address = result.address;
        // Utils.showPrimarySnackbar(context, result.message,
        //     type: SnackType.success);
        showLoader(false);
        notifyListeners();
      }
      notifyListeners();
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  bool isChecked = false;

  void onChecked() {
    isChecked = !isChecked;
    notifyListeners();
  }

  void clearCancellationPopup() {
    reasonController.clear();
    isChecked = false;
    notifyListeners();
  }

  TextEditingController reasonController = TextEditingController();

  OrderCancelledRequestModelShop get orderCancelledRequestModelShop =>
      OrderCancelledRequestModelShop(
        cancelledReasom: reasonController.text,
        shopOrderId: shopOrderId.toString(),
      );
  Future<void> deletedShopProduct(context, shdId) async {
    shopOrderId = shdId.toString();
    showLoader(true);
    SharedPreferences pref = await SharedPreferences.getInstance();
    cancelledShopOrdeRepo
        .cancelledshopOrder(
            orderCancelledRequestModelShop, pref.getString("successToken"))
        .then((response) async {
      final result =
          OrderCancelledResponseModelShop.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        reasonController.clear(); // Clear text field
        isChecked = false; //
        Navigator.push(
          context,
          SlidePageRoute(
            page: MdFoodView(
                // foodOrderID: element?.id.toString(),
                // packageId:MdShopView
                //     widget.packageId,
                ),
            direction: SlideDirection.right, // Specify the slide direction here
            delay: Duration(milliseconds: 5000),
          ),
        );

        // print(cancelId);
        print("object");
        // activePackageList(context);
        // cancelledPackageList(context);
        showLoader(false);
        notifyListeners();
      }
      notifyListeners();
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  // TextEditingController searchCanclledController = TextEditingController();
  // CountrySearchRepo countrySearchRepo = CountrySearchRepo();

  // CountryListModelRequestModel get countryListModelRequestModel =>
  //     CountryListModelRequestModel(
  //       searcchCity: searchCanclledController.text,
  //     );
  // Future<void> countrySearch(context) async {
  //   SharedPreferences pref = await SharedPreferences.getInstance();
  //   print(pref.getString("successToken"));

  //   if (searchCanclledController.text.isNotEmpty) {
  //     countryList ==
  //         countrySearchRepo
  //             .countrysearch(
  //                 countryListModelRequestModel, pref.getString("successToken"))
  //             .then((response) {
  //           log("response.body${response.body}");
  //           final result =
  //               CountryListModelOrderRes.fromJson(jsonDecode(response.body));
  //           if (response.statusCode == 200) {
  //             countryList = result.countryList;
  //             notifyListeners();
  //           } else {
  // Utils.showPrimarySnackbar(context, result.message,
  //     type: SnackType.error);
  //           }
  //         }).onError((error, stackTrace) {
  //           Utils.showPrimarySnackbar(context, error,
  //               type: SnackType.debugError);
  //         }).catchError(
  //           (Object e) {
  //             Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
  //           },
  //           test: (Object e) {
  //             Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
  //             return false;
  //           },
  //         );
  //   } else {
  //     // If the search text is empty, display all packages
  //     await getCountry(context);
  //     notifyListeners();
  //   }
  // }

  List<CountryList>? countryList;
  CountryListRepository countryListRepo = CountryListRepository();

  Future<void> getCountry(context) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    countryListRepo.getCountries(context).then((response) {
      print(response.body);
      final result =
          CountryListModelOrderRes.fromJson(jsonDecode(response.body));
      print(response.statusCode);
      if (response.statusCode == 200) {
        print(response.body);
        countryList = result.countryList;
        print(countryList);
        notifyListeners();
      } else {
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  List<CityListData>? cityList;

  CityListRequestModel get requestModel =>
      CityListRequestModel(countryId: countryId.toString());

  Future<void> getCities(context, cId) async {
    countryId = cId;
    cityListRepo.getCityList(requestModel, context).then((response) {
      final result = CityListResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        if (result.status == 200) {
          cityList = result.cityList;
          debugPrint(cityList?[1].toString());
          notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, result.message,
              type: SnackType.error);
        }
      } else {
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
  /////////////////////////////////////////////////////

  TextEditingController chnageAddressController = TextEditingController();
  ChangeAddresstRequestModel get changeAddresstRequestModel =>
      ChangeAddresstRequestModel(
        address: chnageAddressController.text,
        countryId: selectedCountry.toString(),
        cityId: selectedCity.toString(),
      );

  Future<void> chnageAddress(context, sCountry, sCity, changeadd, shdId) async {
    selectedCountry = sCountry;
    selectedCity = sCity;
    chnageAddressController = changeadd;
    // LoadingOverlay.of(context).show();
    SharedPreferences pref = await SharedPreferences.getInstance();
    changeAddressRepo
        .chnageAddress(
            changeAddresstRequestModel, pref.getString("successToken"))

        // changeAddressRepo
        //     .chnageAddress(changeAddresstRequestModel, token)
        .then((response) {
      final result =
          ChangeAddresstResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        if (result.status == 200) {
          ShopOrderDetailsView(context, shdId);
          Navigator.push(
            context,
            SlidePageRoute(
              page: OrderMdShopView(
                  // packageId:MdShopView
                  //     widget.packageId,
                  ),
              direction:
                  SlideDirection.left, // Specify the slide direction here
              delay: Duration(milliseconds: 5000),
            ),
          );
          // cityList = result.cityList;
          // debugPrint(cityList?[1].toString());
          notifyListeners();

          Utils.showPrimarySnackbar(context, result.message,
              type: SnackType.success);
          // notifyListeners();
        } else {
          Utils.showPrimarySnackbar(context, result.message,
              type: SnackType.error);
          // LoadingOverlay.of(context).hide();
        }
      } else {
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
}
