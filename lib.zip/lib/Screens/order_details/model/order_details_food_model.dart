class OrderListDetailsRequestModel {
  String? foodOrderId;
  OrderListDetailsRequestModel({
    this.foodOrderId,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data["order_id"] = foodOrderId;

    return data;
  }
}

////////////////////////////////////////////////////////////////////////
class OrderListReponseModel {
  int? status;
  String? message;
  OrderFoodDetails? orderFoodDetails;

  OrderListReponseModel({
    required this.status,
    required this.message,
    required this.orderFoodDetails,
  });
  OrderListReponseModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
    orderFoodDetails = json['order_details'] != null
        ? OrderFoodDetails.fromJson(json['order_details'])
        : null;
  }
}

class OrderFoodDetails {
  int? foodPackageIdnew;
  int? id;
  String? orderId;
  String? foodPackageTotalPrice;
  String? packageName;
  String? subscriptionStartDate;
  String? subscriptionEndDate;
  String? orderStatus;
  String? paymentMethod;
  String? address;
  String? companyLogoImagePath;
  String? foodType;
  String? calories;
  int? remainingDays;
  String? type;
  int? useDays;
  String? packageFor;
  String? countryName;
  String? cityName;

  OrderFoodDetails({
    required this.foodPackageIdnew,
    required this.id,
    required this.orderId,
    required this.foodPackageTotalPrice,
    required this.packageName,
    required this.subscriptionStartDate,
    required this.subscriptionEndDate,
    required this.orderStatus,
    required this.paymentMethod,
    required this.address,
    required this.companyLogoImagePath,
    required this.foodType,
    required this.calories,
    required this.remainingDays,
    required this.useDays,
    required this.type,
    required this.packageFor,
    required this.countryName,
    required this.cityName,
  });
  OrderFoodDetails.fromJson(Map<String, dynamic> json) {
    foodPackageIdnew = json["food_package_id"];
    id = json["id"];
    orderId = json["order_id"];
    foodPackageTotalPrice = json["food_package_total_price"];
    packageName = json["package_name"];
    subscriptionStartDate = json["subscription_start_date"];
    subscriptionEndDate = json["subscription_end_date"];
    orderStatus = json["order_status"];
    paymentMethod = json["payment_method"];
    address = json["address"];
    companyLogoImagePath = json["company_logo_image_path"];
    foodType = json["food_type"];
    calories = json["calories"];
    remainingDays = json["remaining_days"];
    type = json["type"];
    useDays = json["used_days"];
    packageFor = json["package_for"];
    countryName = json["country"];
    cityName = json["city"];
  }
}
