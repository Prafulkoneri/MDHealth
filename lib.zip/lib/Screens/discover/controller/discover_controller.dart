import 'package:flutter/material.dart';

class DiscoverController extends ChangeNotifier{}