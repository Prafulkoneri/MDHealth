class SearchListRequestModel {
  String? cityName;
  String? tretmentName;
  String? platformType;

  SearchListRequestModel({
    this.cityName,
    this.platformType,
    this.tretmentName,
  });

  SearchListRequestModel.fromJson(Map<String, dynamic> json) {
    cityName = json["city_name"];
    platformType = json["platform_type"];
    tretmentName = json["treatment_name"];
  }

  Map<String, dynamic> toJson() => {
        "city_name": cityName,
        "platform_type": platformType,
        "treatment_name": tretmentName,
      };
}

////////////////////////////////////////////////////////////////////////////////

class SearchListResponseModel {
  int? status;
  String? message;
  Data? data;

  SearchListResponseModel({
    this.status,
    this.message,
    this.data,
  });

  factory SearchListResponseModel.fromJson(Map<String, dynamic> json) =>
      SearchListResponseModel(
        status: json["status"],
        message: json["message"],
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "data": data?.toJson(),
      };
}

class Data {
  List<PackageList>? packageList;

  Data({
    this.packageList,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        packageList: json["package_list"] == null
            ? []
            : List<PackageList>.from(
                json["package_list"]!.map((x) => PackageList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "package_list": packageList == null
            ? []
            : List<dynamic>.from(packageList!.map((x) => x.toJson())),
      };
}

class PackageList {
  int? id;
  String? packageUniqueNo;
  String? treatmentName;
  String? packageName;
  String? treatmentPeriodInDays;
  dynamic otherServices;
  String? packagePrice;
  String? salePrice;
  String? productCategoryName;
  String? productSubCategoryName;
  String? cityName;
  String? verified;

  PackageList({
    this.id,
    this.packageUniqueNo,
    this.packageName,
    this.treatmentPeriodInDays,
    this.treatmentName,
    this.otherServices,
    this.packagePrice,
    this.salePrice,
    this.productCategoryName,
    this.productSubCategoryName,
    this.cityName,
    this.verified,
  });

  factory PackageList.fromJson(Map<String, dynamic> json) => PackageList(
        id: json["id"],
        packageUniqueNo: json["package_unique_no"],
        treatmentName: json["treatment_name"],
        packageName: json["package_name"],
        treatmentPeriodInDays: json["treatment_period_in_days"],
        otherServices: json["other_services"],
        packagePrice: json["package_price"],
        salePrice: json["sale_price"],
        productCategoryName: json["product_category_name"],
        productSubCategoryName: json["product_sub_category_name"],
        cityName: json["city_name"],
        verified: json["verified"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "package_unique_no": packageUniqueNo,
        "package_name": packageName,
        "treatment_period_in_days": treatmentPeriodInDays,
        "other_services": otherServices,
        "package_price": packagePrice,
        "sale_price": salePrice,
        "product_category_name": productCategoryName,
        "product_sub_category_name": productSubCategoryName,
        "city_name": cityName,
        "verified": verified,
      };
}

////////////////////////////////////////////////////////////////////////////////


