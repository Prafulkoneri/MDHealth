class SearchDetailsListRequestModel {
  String? id;

  SearchDetailsListRequestModel({
    this.id,
  });

  SearchDetailsListRequestModel.fromJson(Map<String, dynamic> json) {
    id = json["id"];
  }

  Map<String, dynamic> toJson() => {
        "id": id,
      };
}

////////////////////////////////////////////////////////////////////////////////

class SearchDetailsListResponseModel {
  int? status;
  String? message;
  PackagesDetails? packagesDetails;
  List<String>? providerGallery;

  SearchDetailsListResponseModel({
    this.status,
    this.message,
    this.packagesDetails,
    this.providerGallery,
  });

  SearchDetailsListResponseModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
    packagesDetails = json["packages_details"] != null
        ? PackagesDetails.fromJson(json["packages_details"])
        : null;
    providerGallery = json["provider_gallery"] != null
        ? List<String>.from(json["provider_gallery"]!.map((x) => x))
        : null;
  }

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "packages_details": packagesDetails?.toJson(),
        "provider_gallery": providerGallery == null
            ? []
            : List<String>.from(providerGallery!.map((x) => x)),
      };
}

class PackagesDetails {
  int? id;
  String? packageUniqueNo;
  int? cityId;
  String? reviewStars;
  String? totalReviews;
  String? verboseReview;
  String? treatmentName;
  String? overview;
  String? packageName;
  int? treatmentCategoryId;
  int? treatmentId;
  List<String>? otherServices;
  String? treatmentPeriodInDays;
  String? treatmentPrice;
  String? cityName;
  String? packagePrice;

  PackagesDetails({
    this.id,
    this.packageUniqueNo,
    this.cityId,
    this.reviewStars,
    this.treatmentName,
    this.totalReviews,
    this.verboseReview,
    this.overview,
    this.packageName,
    this.treatmentCategoryId,
    this.treatmentId,
    this.otherServices,
    this.treatmentPeriodInDays,
    this.treatmentPrice,
    this.cityName,
    this.packagePrice,
  });

  PackagesDetails.fromJson(Map<String, dynamic> json) {
    id = json["id"];
    packageUniqueNo = json["package_unique_no"];
    treatmentName = json["treatment_name"];
    cityId = json["city_id"];
    reviewStars = json["review_stars"];
    totalReviews = json["total_reviews"];
    verboseReview = json["verbose_review"];
    overview = json["overview"];
    packageName = json["package_name"];
    packagePrice = json["package_price"];
    treatmentCategoryId = json["treatment_category_id"];
    treatmentId = json["treatment_id"];
    otherServices = json["other_services"] != null
        ? List<String>.from(json["other_services"]!.map((x) => x))
        : null;
    treatmentPeriodInDays = json["treatment_period_in_days"];
    treatmentPrice = json["treatment_price"];
    cityName = json["city_name"];
  }

  Map<String, dynamic> toJson() => {
        "id": id,
        "package_unique_no": packageUniqueNo,
        "treatment_name": treatmentName,
        "city_id": cityId,
        "review_stars": reviewStars,
        "total_reviews": totalReviews,
        "verbose_review": verboseReview,
        "overview": overview,
        "package_name": packageName,
        "treatment_category_id": treatmentCategoryId,
        "treatment_id": treatmentId,
        "other_services": otherServices != null
            ? List<String>.from(otherServices!.map((x) => x))
            : null,
        "treatment_period_in_days": treatmentPeriodInDays,
        "treatment_price": treatmentPrice,
        "city_name": cityName,
      };
}
