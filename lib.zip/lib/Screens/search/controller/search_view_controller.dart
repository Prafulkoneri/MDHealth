import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:md_health/Screens/search/model/search_model.dart';
import 'package:md_health/Screens/search/model/search_details_model.dart';
import 'package:md_health/Screens/search/repository/search_details_view_repository.dart';
import 'package:md_health/Screens/search/repository/search_view_repository.dart';
import 'package:md_health/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SearchViewController extends ChangeNotifier {
  SearchViewRepository packageRepository = SearchViewRepository();
  List<String>? galleryList;
  List<PackageList>? packageList;
  bool isLoading = true;
  PackagesDetails? packageDetails;
  String? packageId;
  String? cityName;
  String? tretmentName;
  SearchViewRepository packageViewRepository = SearchViewRepository();

  Future<void> initState(context, cName, tName
      // refresh,
      // cityName,
      // platformType,
      ) async {
    // if (refresh) {

    // }
    getPackages(context, cName, tName);
    notifyListeners();
  }

  int? selectedTextIndex;
  void setSelectedText(value, index) {
    selectedTextIndex = index;
    notifyListeners();
  }
// bool isLoading = true;

  showLoader(value) {
    isLoading = value;
    notifyListeners();
  }

  void setPackageId(int value) {
    packageId = value.toString();
    notifyListeners();
  }

  setPackageList(List<PackageList>? list) {
    packageList = list;
    log(packageList![0].packageName ?? ''); // Method to update packageList
    notifyListeners();
  }

  SearchListRequestModel get packageRequestModel => SearchListRequestModel(
      tretmentName: tretmentName, cityName: cityName, platformType: "android");

  Future<void> getPackages(context, cName, tName) async {
    // showLoader(true);
    cityName = cName.toString();
    tretmentName = tName.toString();
    // packageList = [];
    SharedPreferences pref = await SharedPreferences.getInstance();
    packageRepository
        .getPackages(packageRequestModel, pref.getString("successToken"))
        .then((response) async {
      log(response.body);
      final result =
          SearchListResponseModel.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);

        packageList = result.data?.packageList;
        print(packageList?[0].packageName);
        // showLoader(false);
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }

  // PackageViewRequestModel requestModel =
  // PackageViewRequestModel(
  //     id: packageId.toString());

  // PackageViewRequestModel get requestModel =>
  //     PackageViewRequestModel( id: packageId.toString());
  //
  // Future<void> showDetails(context, packId)async{
  //   final id = packId.toString();
  //   SharedPreferences pref = await SharedPreferences.getInstance();
  //   packageViewRepository.getPackages(requestModel, pref.get('successToken')).then((response) {
  //     print(response.body);
  //     final result =
  //     PackageViewResponseModel.fromJson(jsonDecode(response.body));
  //     print(response.statusCode);
  //     if (response.statusCode == 200) {
  //       print(response.body);
  //       if (result.status == 200) {
  //
  //         packageDetails =  result.packagesDetails;
  //         galleryList = result.providerGallery;
  //         Navigator.push(context, MaterialPageRoute(builder: (context) => const HomeSearchViewDetails()));
  //         // pref.setString(
  //         //     "successToken", result.registrationdata?.accessToken ?? "");
  //         // print("4444444444444444444444444444444444444444");
  //         // print(pref.getString("successToken"));
  //         // print("4444444444444444444444444444444444444444");
  //         notifyListeners();
  //       } else {
  //         Utils.showPrimarySnackbar(context, result.message,
  //             type: SnackType.error);
  //       }
  //     } else {
  //       Utils.showPrimarySnackbar(context, result.message,
  //           type: SnackType.error);
  //     }
  //   }).onError((error, stackTrace) {
  //     Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
  //   }).catchError(
  //         (Object e) {
  //       Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
  //     },
  //     test: (Object e) {
  //       Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
  //       return false;
  //     },
  //   );
  // }
}
