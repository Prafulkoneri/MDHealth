import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:md_health/diet_plan%20_payment/model/diet_plan_model.dart';
import 'package:md_health/diet_plan%20_payment/repository/diet_plan_repo.dart';
import 'package:md_health/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DietPlanPaymertController extends ChangeNotifier {
  DietPAymentDetailsRepo dietPAymentDetailsRepo = DietPAymentDetailsRepo();
  bool isLoading = false;

  Future<void> initState(
    context,
    foodId,
    dateS,
    subscType,
    parchType,
    paDaiteId,
    sPrices,
  ) async {
    await dietPaymentDetail(
      context,
      foodId,
      dateS,
      subscType,
      parchType,
      paDaiteId,
      sPrices,
    );

    notifyListeners();
  }

  DietPaymentDetailsData? dietPaymentdetailsdata;
  CustomerList? customerList;
  String? foodpackageId;
  String? subscriptionType;
  String? type;
  String? patientId;
  String? salePrice;
  String? dateSubscription;
  DietViewRequestModelPayment get dietViewRequestModelPayment =>
      DietViewRequestModelPayment(
        foodpackageId: foodpackageId,
        subscriptionDate: dateSubscription,
        subscriptionType: subscriptionType,
        type: type,
        patientId: patientId,
        salePrices: salePrice,
      );
  Future<void> dietPaymentDetail(
    context,
    foodId,
    dateS,
    subscType,
    parchType,
    paDaiteId,
    sPrices,
  ) async {
    foodpackageId = foodId.toString();
    dateSubscription = dateS.toString();
    subscriptionType = subscType.toString();
    type = parchType.toString();
    patientId = paDaiteId.toString();
    salePrice = sPrices.toString();
    // showLoader(true);

    SharedPreferences pref = await SharedPreferences.getInstance();
    dietPAymentDetailsRepo
        .dietPaymnet(
            dietViewRequestModelPayment, pref.getString("successToken"))
        .then((response) async {
      debugPrint('/////////////');
      final result =
          DietViewReponseModelPayment.fromJson(jsonDecode(response.body));
      if (response.statusCode == 200) {
        log(response.body);
        dietPaymentdetailsdata = result.dietPaymentdetailsdata;
        customerList = result.customerList;
        print("juhujkiuyol,oi;l");
        notifyListeners();
      } else {
        log(response.body);
        Utils.showPrimarySnackbar(context, result.message,
            type: SnackType.error);
      }
    }).onError((error, stackTrace) {
      Utils.showPrimarySnackbar(context, error, type: SnackType.debugError);
    }).catchError(
      (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
      },
      test: (Object e) {
        Utils.showPrimarySnackbar(context, e, type: SnackType.debugError);
        return false;
      },
    );
  }
}
